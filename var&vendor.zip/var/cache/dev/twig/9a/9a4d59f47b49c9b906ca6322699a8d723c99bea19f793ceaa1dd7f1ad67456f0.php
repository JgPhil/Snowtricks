<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* app/index.html.twig */
class __TwigTemplate_1a306d0fbaff45ac9b247516491b6664edb70f9134a2059bf9b822ce37d5e16f extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'body' => [$this, 'block_body'],
            'javascript' => [$this, 'block_javascript'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "app/index.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "app/index.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "app/index.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "All Tricks";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 4
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 5
        echo "
\t<div class=\"container\">
\t\t";
        // line 7
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 7, $this->source); })()), "flashes", [0 => "info"], "method", false, false, false, 7));
        foreach ($context['_seq'] as $context["_key"] => $context["message"]) {
            // line 8
            echo "\t\t\t<div class=\"flash-info\">
\t\t\t\t<div class=\"alert alert-success\">";
            // line 9
            echo twig_escape_filter($this->env, $context["message"], "html", null, true);
            echo "</div>
\t\t\t</div>
\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['message'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 12
        echo "\t\t";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 12, $this->source); })()), "flashes", [0 => "message"], "method", false, false, false, 12));
        foreach ($context['_seq'] as $context["_key"] => $context["message"]) {
            // line 13
            echo "\t\t\t<div class=\"flash-info\">
\t\t\t\t<div class=\"alert alert-success\">";
            // line 14
            echo twig_escape_filter($this->env, $context["message"], "html", null, true);
            echo "</div>
\t\t\t</div>
\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['message'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 17
        echo "\t\t";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 17, $this->source); })()), "flashes", [0 => "danger"], "method", false, false, false, 17));
        foreach ($context['_seq'] as $context["_key"] => $context["message"]) {
            // line 18
            echo "\t\t\t<div class=\"flash-info\">
\t\t\t\t<div class=\"alert alert-danger\">";
            // line 19
            echo twig_escape_filter($this->env, $context["message"], "html", null, true);
            echo "</div>
\t\t\t</div>
\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['message'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 22
        echo "\t</div>
\t<!-- FIGURE A LA UNE -->


\t<div class=\"jumbotron jumbotron-fluid align-items-center justify-content-center\" id=\"topJumbotron\">
\t\t<div class=\"container-fluid\">

\t\t\t<h1 class=\"display-3\">Snowtricks</h1>

\t\t\t<hr>

\t\t\t<p class=\"lead display-4\">
\t\t\t\tPremière source de référence de figures de snowboard.
\t\t\t</p>


\t\t\t";
        // line 39
        echo "\t\t\t<a class=\"btn-scroll scroll-down\" href=\"#js-more\">
\t\t\t\t<i class=\"fas fa-arrow-down\"></i>
\t\t\t</a>

\t\t</div>
\t</div>

\t<!-- TOUTES LES FIGURES -->

\t<div class=\"container figures-container\" id=\"block-figures\">
\t\t<div class=\"row mt-4\" id=\"js-more\">

\t\t\t";
        // line 51
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["figures"]) || array_key_exists("figures", $context) ? $context["figures"] : (function () { throw new RuntimeError('Variable "figures" does not exist.', 51, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["figure"]) {
            // line 52
            echo "\t\t\t\t";
            if (0 !== twig_compare(twig_get_attribute($this->env, $this->source, $context["figure"], "activatedAt", [], "any", false, false, false, 52), null)) {
                // line 53
                echo "\t\t\t\t\t
\t\t\t\t\t";
                // line 54
                $context["picturePath"] = null;
                // line 55
                echo "\t\t\t\t\t";
                $context["defaultPicture"] = null;
                // line 56
                echo "\t\t\t\t\t";
                // line 57
                echo "\t\t\t\t\t";
                if ( !twig_test_empty(twig_get_attribute($this->env, $this->source, $context["figure"], "pictures", [], "any", false, false, false, 57))) {
                    // line 58
                    echo "\t\t\t\t\t\t";
                    $context['_parent'] = $context;
                    $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, $context["figure"], "pictures", [], "any", false, false, false, 58));
                    foreach ($context['_seq'] as $context["_key"] => $context["picture"]) {
                        // line 59
                        echo "\t\t\t\t\t\t\t";
                        if (0 === twig_compare(twig_get_attribute($this->env, $this->source, $context["picture"], "sortOrder", [], "any", false, false, false, 59), 1)) {
                            // line 60
                            echo "\t\t\t\t\t\t\t\t";
                            $context["defaultPicture"] = $context["picture"];
                            // line 61
                            echo "\t\t\t\t\t\t\t\t";
                            $context["picturePath"] = ("/uploads/pictures/" . twig_get_attribute($this->env, $this->source, $context["picture"], "name", [], "any", false, false, false, 61));
                            // line 62
                            echo "\t\t\t\t\t\t\t";
                        }
                        // line 63
                        echo "\t\t\t\t\t\t";
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['_iterated'], $context['_key'], $context['picture'], $context['_parent'], $context['loop']);
                    $context = array_intersect_key($context, $_parent) + $_parent;
                    // line 64
                    echo "
\t\t\t\t\t\t";
                    // line 66
                    echo "\t\t\t\t\t";
                }
                // line 67
                echo "
\t\t\t\t\t<div class=\"col-sm-6 col-md-4 col-lg-3\">
\t\t\t\t\t\t<div class=\"card mb-4 \">
\t\t\t\t\t\t\t<img class=\"card-img-top\" src=\"";
                // line 70
                echo twig_escape_filter($this->env, (((isset($context["picturePath"]) || array_key_exists("picturePath", $context))) ? (_twig_default_filter((isset($context["picturePath"]) || array_key_exists("picturePath", $context) ? $context["picturePath"] : (function () { throw new RuntimeError('Variable "picturePath" does not exist.', 70, $this->source); })()), "uploads/pictures/fail.jpg")) : ("uploads/pictures/fail.jpg")), "html", null, true);
                echo "\" alt=\"Une image de la figure ";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["figure"], "title", [], "any", false, false, false, 70), "html", null, true);
                echo "\">
\t\t\t\t\t\t\t<div class=\"card-body\">
\t\t\t\t\t\t\t\t<div class=\"row \">
\t\t\t\t\t\t\t\t\t<h5 class=\"col-7\">
\t\t\t\t\t\t\t\t\t\t<a href=\"";
                // line 74
                echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("trick_show", ["id" => twig_get_attribute($this->env, $this->source, $context["figure"], "id", [], "any", false, false, false, 74)]), "html", null, true);
                echo "\">
\t\t\t\t\t\t\t\t\t\t\t";
                // line 75
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["figure"], "title", [], "any", false, false, false, 75), "html", null, true);
                echo "
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</h5>

\t\t\t\t\t\t\t\t\t";
                // line 79
                if (twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 79, $this->source); })()), "user", [], "any", false, false, false, 79)) {
                    // line 80
                    echo "\t\t\t\t\t\t\t\t\t\t<div class=\"col-5\">
\t\t\t\t\t\t\t\t\t\t\t<a href=\"";
                    // line 81
                    echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("figure_edit", ["id" => twig_get_attribute($this->env, $this->source, $context["figure"], "id", [], "any", false, false, false, 81)]), "html", null, true);
                    echo "\" class=\"p-1\">
\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"fas fa-pencil-alt fa-2x\"></i>
\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t<a href=\"";
                    // line 84
                    echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_figure_desactivate", ["id" => twig_get_attribute($this->env, $this->source, $context["figure"], "id", [], "any", false, false, false, 84)]), "html", null, true);
                    echo "\" class=\"p-1\" data-delete>
\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"fas fa-trash-alt fa-2x\"></i>
\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t";
                }
                // line 89
                echo "
\t\t\t\t\t\t\t\t</div>


\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t";
            }
            // line 97
            echo "\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['figure'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 98
        echo "\t\t</div>
\t\t<div class=\"row\">

\t\t\t<div class=\"col text-center\">
\t\t\t\t<a class=\"btn btn-success\" id=\"js-load\">
\t\t\t\t\tLoad More</a>
\t\t\t\t";
        // line 105
        echo "\t\t\t\t<a class=\"btn-scroll scroll-up\" id=\"js-btn-scroll-up\" href=\"#js-more\" hidden>
\t\t\t\t\t<i class=\"fas fa-arrow-up\"></i>
\t\t\t\t</a>
\t\t\t</div>


\t\t</div>
\t</div>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 115
    public function block_javascript($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascript"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascript"));

        // line 116
        echo "\t<script>
\t\twindow.user = ";
        // line 117
        echo (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 117, $this->source); })());
        echo ";
\t</script>
\t<script src=\" ";
        // line 119
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("/js/loadMore.js"), "html", null, true);
        echo "\"></script>
\t<script src=\" ";
        // line 120
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/figure_delete.js"), "html", null, true);
        echo " \"></script>
\t<script src=\" ";
        // line 121
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/scrollUpBtn.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "app/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  337 => 121,  333 => 120,  329 => 119,  324 => 117,  321 => 116,  311 => 115,  292 => 105,  284 => 98,  278 => 97,  268 => 89,  260 => 84,  254 => 81,  251 => 80,  249 => 79,  242 => 75,  238 => 74,  229 => 70,  224 => 67,  221 => 66,  218 => 64,  212 => 63,  209 => 62,  206 => 61,  203 => 60,  200 => 59,  195 => 58,  192 => 57,  190 => 56,  187 => 55,  185 => 54,  182 => 53,  179 => 52,  175 => 51,  161 => 39,  143 => 22,  134 => 19,  131 => 18,  126 => 17,  117 => 14,  114 => 13,  109 => 12,  100 => 9,  97 => 8,  93 => 7,  89 => 5,  79 => 4,  60 => 3,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}

{% block title 'All Tricks' %}
{% block body %}

\t<div class=\"container\">
\t\t{% for message in app.flashes('info') %}
\t\t\t<div class=\"flash-info\">
\t\t\t\t<div class=\"alert alert-success\">{{ message }}</div>
\t\t\t</div>
\t\t{% endfor %}
\t\t{% for message in app.flashes('message') %}
\t\t\t<div class=\"flash-info\">
\t\t\t\t<div class=\"alert alert-success\">{{ message }}</div>
\t\t\t</div>
\t\t{% endfor %}
\t\t{% for message in app.flashes('danger') %}
\t\t\t<div class=\"flash-info\">
\t\t\t\t<div class=\"alert alert-danger\">{{ message }}</div>
\t\t\t</div>
\t\t{% endfor %}
\t</div>
\t<!-- FIGURE A LA UNE -->


\t<div class=\"jumbotron jumbotron-fluid align-items-center justify-content-center\" id=\"topJumbotron\">
\t\t<div class=\"container-fluid\">

\t\t\t<h1 class=\"display-3\">Snowtricks</h1>

\t\t\t<hr>

\t\t\t<p class=\"lead display-4\">
\t\t\t\tPremière source de référence de figures de snowboard.
\t\t\t</p>


\t\t\t{# SCROLL DOWN BUTTON  #}
\t\t\t<a class=\"btn-scroll scroll-down\" href=\"#js-more\">
\t\t\t\t<i class=\"fas fa-arrow-down\"></i>
\t\t\t</a>

\t\t</div>
\t</div>

\t<!-- TOUTES LES FIGURES -->

\t<div class=\"container figures-container\" id=\"block-figures\">
\t\t<div class=\"row mt-4\" id=\"js-more\">

\t\t\t{% for figure in figures %}
\t\t\t\t{% if figure.activatedAt != null %}
\t\t\t\t\t
\t\t\t\t\t{% set picturePath = null %}
\t\t\t\t\t{% set defaultPicture = null %}
\t\t\t\t\t{# search for figure default picture #}
\t\t\t\t\t{% if figure.pictures is not empty %}
\t\t\t\t\t\t{% for picture in figure.pictures %}
\t\t\t\t\t\t\t{% if picture.sortOrder == 1 %}
\t\t\t\t\t\t\t\t{% set defaultPicture = picture %}
\t\t\t\t\t\t\t\t{% set picturePath =  \"/uploads/pictures/\" ~ picture.name %}
\t\t\t\t\t\t\t{% endif %}
\t\t\t\t\t\t{% endfor %}

\t\t\t\t\t\t{#  #}
\t\t\t\t\t{% endif %}

\t\t\t\t\t<div class=\"col-sm-6 col-md-4 col-lg-3\">
\t\t\t\t\t\t<div class=\"card mb-4 \">
\t\t\t\t\t\t\t<img class=\"card-img-top\" src=\"{{picturePath|default('uploads/pictures/fail.jpg') }}\" alt=\"Une image de la figure {{figure.title}}\">
\t\t\t\t\t\t\t<div class=\"card-body\">
\t\t\t\t\t\t\t\t<div class=\"row \">
\t\t\t\t\t\t\t\t\t<h5 class=\"col-7\">
\t\t\t\t\t\t\t\t\t\t<a href=\"{{ path( 'trick_show', { id: figure.id } ) }}\">
\t\t\t\t\t\t\t\t\t\t\t{{ figure.title }}
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</h5>

\t\t\t\t\t\t\t\t\t{% if app.user %}
\t\t\t\t\t\t\t\t\t\t<div class=\"col-5\">
\t\t\t\t\t\t\t\t\t\t\t<a href=\"{{ path('figure_edit', { id: figure.id }) }}\" class=\"p-1\">
\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"fas fa-pencil-alt fa-2x\"></i>
\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t<a href=\"{{ path('admin_figure_desactivate', { id: figure.id }) }}\" class=\"p-1\" data-delete>
\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"fas fa-trash-alt fa-2x\"></i>
\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t{% endif %}

\t\t\t\t\t\t\t\t</div>


\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t{% endif %}
\t\t\t{% endfor %}
\t\t</div>
\t\t<div class=\"row\">

\t\t\t<div class=\"col text-center\">
\t\t\t\t<a class=\"btn btn-success\" id=\"js-load\">
\t\t\t\t\tLoad More</a>
\t\t\t\t{# SCROLL DOWN BUTTON  #}
\t\t\t\t<a class=\"btn-scroll scroll-up\" id=\"js-btn-scroll-up\" href=\"#js-more\" hidden>
\t\t\t\t\t<i class=\"fas fa-arrow-up\"></i>
\t\t\t\t</a>
\t\t\t</div>


\t\t</div>
\t</div>

{% endblock %}
{% block javascript %}
\t<script>
\t\twindow.user = {{ user|raw }};
\t</script>
\t<script src=\" {{ asset('/js/loadMore.js') }}\"></script>
\t<script src=\" {{ asset('js/figure_delete.js') }} \"></script>
\t<script src=\" {{ asset('js/scrollUpBtn.js') }}\"></script>
{% endblock %}
", "app/index.html.twig", "/home/phil/Snowtricks/templates/app/index.html.twig");
    }
}
