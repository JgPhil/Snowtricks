<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* email/reset_password.html.twig */
class __TwigTemplate_db10290d46af6168b17e43ee08879c2cdf72e08b78bb770ec31d4336e0ed9e7f extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "email/reset_password.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "email/reset_password.html.twig"));

        // line 1
        echo "
<h1>Réinitialiser votre mot de passe ";
        // line 2
        echo twig_escape_filter($this->env, (isset($context["username"]) || array_key_exists("username", $context) ? $context["username"] : (function () { throw new RuntimeError('Variable "username" does not exist.', 2, $this->source); })()), "html", null, true);
        echo " </h1>
<p>
\tBonjour, ";
        // line 4
        echo twig_escape_filter($this->env, (isset($context["username"]) || array_key_exists("username", $context) ? $context["username"] : (function () { throw new RuntimeError('Variable "username" does not exist.', 4, $this->source); })()), "html", null, true);
        echo " !
</p>

<p>
\tPour modifier votre mot de passe , merci de cliquer sur le lien suivant:
</p>


<p>
\t<a href=\"";
        // line 13
        echo twig_escape_filter($this->env, (isset($context["url"]) || array_key_exists("url", $context) ? $context["url"] : (function () { throw new RuntimeError('Variable "url" does not exist.', 13, $this->source); })()), "html", null, true);
        echo "\">Réinitialiser mon mot de passe</a>
\tCe lien sera valide jusqu' au
\t";
        // line 15
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, (isset($context["expiration_date"]) || array_key_exists("expiration_date", $context) ? $context["expiration_date"] : (function () { throw new RuntimeError('Variable "expiration_date" does not exist.', 15, $this->source); })()), "d/m/Y"), "html", null, true);
        echo " à
\t";
        // line 16
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, (isset($context["expiration_date"]) || array_key_exists("expiration_date", $context) ? $context["expiration_date"] : (function () { throw new RuntimeError('Variable "expiration_date" does not exist.', 16, $this->source); })()), "H:i"), "html", null, true);
        echo "
</p>
";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "email/reset_password.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  72 => 16,  68 => 15,  63 => 13,  51 => 4,  46 => 2,  43 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("
<h1>Réinitialiser votre mot de passe {{ username }} </h1>
<p>
\tBonjour, {{ username }} !
</p>

<p>
\tPour modifier votre mot de passe , merci de cliquer sur le lien suivant:
</p>


<p>
\t<a href=\"{{ url }}\">Réinitialiser mon mot de passe</a>
\tCe lien sera valide jusqu' au
\t{{ expiration_date|date('d/m/Y') }} à
\t{{ expiration_date|date('H:i') }}
</p>
", "email/reset_password.html.twig", "/home/phil/Snowtricks/templates/email/reset_password.html.twig");
    }
}
