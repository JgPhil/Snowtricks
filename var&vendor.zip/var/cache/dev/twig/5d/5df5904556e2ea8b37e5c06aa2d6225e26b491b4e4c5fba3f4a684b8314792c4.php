<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* app/show.html.twig */
class __TwigTemplate_87574bdc05e61a71aa8af0ee2d76d534022a29d525058edc1fc7d0629d770ca3 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'body' => [$this, 'block_body'],
            'javascript' => [$this, 'block_javascript'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "app/show.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "app/show.html.twig"));

        // line 3
        $this->env->getRuntime("Symfony\\Component\\Form\\FormRenderer")->setTheme((isset($context["commentForm"]) || array_key_exists("commentForm", $context) ? $context["commentForm"] : (function () { throw new RuntimeError('Variable "commentForm" does not exist.', 3, $this->source); })()), [0 => "bootstrap_4_layout.html.twig"], true);
        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "app/show.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 6
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        // line 7
        echo "\t";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["figure"]) || array_key_exists("figure", $context) ? $context["figure"] : (function () { throw new RuntimeError('Variable "figure" does not exist.', 7, $this->source); })()), "title", [], "any", false, false, false, 7), "html", null, true);
        echo "
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 10
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 11
        echo "
\t";
        // line 12
        $context["defaultPicture"] = null;
        // line 13
        echo "
\t<div class=\"container\">
\t\t";
        // line 15
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 15, $this->source); })()), "flashes", [0 => "message"], "method", false, false, false, 15));
        foreach ($context['_seq'] as $context["_key"] => $context["message"]) {
            // line 16
            echo "\t\t\t<div class=\"flash-info\">
\t\t\t\t<div class=\"alert alert-success\">";
            // line 17
            echo twig_escape_filter($this->env, $context["message"], "html", null, true);
            echo "</div>
\t\t\t</div>
\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['message'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 20
        echo "\t\t";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 20, $this->source); })()), "flashes", [0 => "danger"], "method", false, false, false, 20));
        foreach ($context['_seq'] as $context["_key"] => $context["message"]) {
            // line 21
            echo "\t\t\t<div class=\"flash-info\">
\t\t\t\t<div class=\"alert alert-danger\">";
            // line 22
            echo twig_escape_filter($this->env, $context["message"], "html", null, true);
            echo "</div>
\t\t\t</div>
\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['message'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 25
        echo "
\t\t";
        // line 26
        $context["picturesArray"] = twig_get_attribute($this->env, $this->source, (isset($context["figure"]) || array_key_exists("figure", $context) ? $context["figure"] : (function () { throw new RuntimeError('Variable "figure" does not exist.', 26, $this->source); })()), "pictures", [], "any", false, false, false, 26);
        // line 27
        echo "\t\t";
        // line 28
        echo "\t\t";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["picturesArray"]) || array_key_exists("picturesArray", $context) ? $context["picturesArray"] : (function () { throw new RuntimeError('Variable "picturesArray" does not exist.', 28, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["picture"]) {
            // line 29
            echo "\t\t\t";
            if (0 === twig_compare(twig_get_attribute($this->env, $this->source, $context["picture"], "sortOrder", [], "any", false, false, false, 29), 1)) {
                // line 30
                echo "\t\t\t\t";
                $context["defaultPicture"] = $context["picture"];
                // line 31
                echo "\t\t\t";
            }
            // line 32
            echo "\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['picture'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 33
        echo "
\t\t";
        // line 34
        $context["pictureJumbotron"] = (((isset($context["defaultPicture"]) || array_key_exists("defaultPicture", $context) ? $context["defaultPicture"] : (function () { throw new RuntimeError('Variable "defaultPicture" does not exist.', 34, $this->source); })())) ? ((" /uploads/pictures/" . twig_get_attribute($this->env, $this->source, (isset($context["defaultPicture"]) || array_key_exists("defaultPicture", $context) ? $context["defaultPicture"] : (function () { throw new RuntimeError('Variable "defaultPicture" does not exist.', 34, $this->source); })()), "name", [], "any", false, false, false, 34))) : (""));
        // line 35
        echo "\t\t<div class=\"show_main_picture align-items-center justify-content-center\" style=\"background: url(' ";
        echo twig_escape_filter($this->env, (((isset($context["pictureJumbotron"]) || array_key_exists("pictureJumbotron", $context))) ? (_twig_default_filter((isset($context["pictureJumbotron"]) || array_key_exists("pictureJumbotron", $context) ? $context["pictureJumbotron"] : (function () { throw new RuntimeError('Variable "pictureJumbotron" does not exist.', 35, $this->source); })()), "/uploads/pictures/fail.jpg")) : ("/uploads/pictures/fail.jpg")), "html", null, true);
        echo " ') no-repeat center;
\t\t\t\t\t\t\t\t\t\tbackground-size: cover;
\t\t\t\t\t\t\t\t\t\tbackground-position: center top;
\t\t\t\t\t\t\t\t\t\theight: 500px;\">
\t\t\t<h1 class=\"display-4\" style=\"color: white\">
\t\t\t\t";
        // line 40
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["figure"]) || array_key_exists("figure", $context) ? $context["figure"] : (function () { throw new RuntimeError('Variable "figure" does not exist.', 40, $this->source); })()), "title", [], "any", false, false, false, 40));
        echo "
\t\t\t</h1>

\t\t\t<div hidden id=\"figureId\">
\t\t\t\t";
        // line 44
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["figure"]) || array_key_exists("figure", $context) ? $context["figure"] : (function () { throw new RuntimeError('Variable "figure" does not exist.', 44, $this->source); })()), "id", [], "any", false, false, false, 44), "html", null, true);
        echo "
\t\t\t</div>


\t\t\t";
        // line 48
        if (twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 48, $this->source); })()), "user", [], "any", false, false, false, 48)) {
            // line 49
            echo "
\t\t\t\t<div class=\"editButtonMenu\">
\t\t\t\t\t<a href=\"";
            // line 51
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("figure_edit", ["id" => twig_get_attribute($this->env, $this->source, (isset($context["figure"]) || array_key_exists("figure", $context) ? $context["figure"] : (function () { throw new RuntimeError('Variable "figure" does not exist.', 51, $this->source); })()), "id", [], "any", false, false, false, 51)]), "html", null, true);
            echo "\" class=\"mr-2\">
\t\t\t\t\t\t<i class=\"fas fa-pencil-alt fa-2x\" title=\"modifier la figure\"></i>
\t\t\t\t\t</a>
\t\t\t\t\t<a href=\"";
            // line 54
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("delete_figure", ["id" => twig_get_attribute($this->env, $this->source, (isset($context["figure"]) || array_key_exists("figure", $context) ? $context["figure"] : (function () { throw new RuntimeError('Variable "figure" does not exist.', 54, $this->source); })()), "id", [], "any", false, false, false, 54)]), "html", null, true);
            echo "\" onclick=\"return confirm('êtes-vous sûr de vouloir effacer cette figure ?');\">
\t\t\t\t\t\t<i class=\"fas fa-trash-alt fa-2x\" title=\"supprimer la figure\"></i>
\t\t\t\t\t</a>
\t\t\t\t</div>

\t\t\t";
        }
        // line 60
        echo "
\t\t</div>

\t\t<div class=\"container-fluid\">
\t\t\t<div class=\"row justify-content-center d-md-none\">
\t\t\t\t<a data-toggle=\"collapse\" href=\"#media-block-show\" role=\"button\" aria-expanded=\"false\" aria-controls=\"media-block-show\">
\t\t\t\t\t<i class=\"fas fa-images fa-2x\">
\t\t\t\t\t\tVoir les Médias</i>
\t\t\t\t</a>
\t\t\t</div>

\t\t\t<div class=\"row collapse media-block d-md-flex mb-4\" id=\"media-block-show\">
\t\t\t\t<div class=\"col-sm-12 col-md-6 pictures-container\">
\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t";
        // line 74
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_array_filter((isset($context["picturesArray"]) || array_key_exists("picturesArray", $context) ? $context["picturesArray"] : (function () { throw new RuntimeError('Variable "picturesArray" does not exist.', 74, $this->source); })()), function ($__picture__) use ($context, $macros) { $context["picture"] = $__picture__; return 0 !== twig_compare(twig_get_attribute($this->env, $this->source, $context["picture"], "sortOrder", [], "any", false, false, false, 74), 1); }));
        foreach ($context['_seq'] as $context["_key"] => $context["picture"]) {
            // line 75
            echo "\t\t\t\t\t\t\t<div class=\"col-sm-12 col-md-6 col-lg-4 mx-auto\">
\t\t\t\t\t\t\t\t";
            // line 76
            $context["picturePath"] = ("/uploads/pictures/" . twig_get_attribute($this->env, $this->source, $context["picture"], "name", [], "any", false, false, false, 76));
            // line 77
            echo "\t\t\t\t\t\t\t\t<img class=\"img-responsive\" width=\"100%\" src=\"";
            echo twig_escape_filter($this->env, (((isset($context["picturePath"]) || array_key_exists("picturePath", $context))) ? (_twig_default_filter((isset($context["picturePath"]) || array_key_exists("picturePath", $context) ? $context["picturePath"] : (function () { throw new RuntimeError('Variable "picturePath" does not exist.', 77, $this->source); })()), "http://placehold.it/300x200")) : ("http://placehold.it/300x200")), "html", null, true);
            echo "\" alt=\"Une image de la figure ";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["figure"]) || array_key_exists("figure", $context) ? $context["figure"] : (function () { throw new RuntimeError('Variable "figure" does not exist.', 77, $this->source); })()), "title", [], "any", false, false, false, 77), "html", null, true);
            echo "\" onclick=\"window.open(this.src)\">
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['picture'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 80
        echo "\t\t\t\t\t</div>
\t\t\t\t</div>

\t\t\t\t<div class=\"col-sm-12 col-md-6 videos-container\">
\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t";
        // line 85
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, (isset($context["figure"]) || array_key_exists("figure", $context) ? $context["figure"] : (function () { throw new RuntimeError('Variable "figure" does not exist.', 85, $this->source); })()), "videos", [], "any", false, false, false, 85));
        foreach ($context['_seq'] as $context["_key"] => $context["video"]) {
            // line 86
            echo "\t\t\t\t\t\t\t<div class=\" col-sm-12 col-md-6 col-lg-4 mx-auto\">
\t\t\t\t\t\t\t\t<div class=\"iframe-container embed-responsive embed-responsive-16by9\">
\t\t\t\t\t\t\t\t\t<iframe class=\"embed-responsive-item\" src=\"";
            // line 88
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["video"], "url", [], "any", false, false, false, 88), "html", null, true);
            echo "\" allow=\"accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['video'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 92
        echo "
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</div>

\t<div class=\"container\">
\t\t<p class=\"lead mt-4 mb-4\">";
        // line 100
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["figure"]) || array_key_exists("figure", $context) ? $context["figure"] : (function () { throw new RuntimeError('Variable "figure" does not exist.', 100, $this->source); })()), "description", [], "any", false, false, false, 100), "html", null, true);
        echo "</p>
\t\t<div class=\"row justify-content-center \">
\t\t\t<div class=\"col-lg-8\">

\t\t\t\t<div class=\"row align-items-center meta-box mt-4 mb-4\">

\t\t\t\t\t<div class=\"col-3 \">
\t\t\t\t\t\t<div class=\"meta\">Créée le
\t\t\t\t\t\t\t";
        // line 108
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["figure"]) || array_key_exists("figure", $context) ? $context["figure"] : (function () { throw new RuntimeError('Variable "figure" does not exist.', 108, $this->source); })()), "createdAt", [], "any", false, false, false, 108), "d/m/Y"), "html", null, true);
        echo "
\t\t\t\t\t\t</div>

\t\t\t\t\t</div>

\t\t\t\t\t<div class=\"col-3 \">
\t\t\t\t\t\t<div class=\"meta\">Catégorie
\t\t\t\t\t\t\t";
        // line 115
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["figure"]) || array_key_exists("figure", $context) ? $context["figure"] : (function () { throw new RuntimeError('Variable "figure" does not exist.', 115, $this->source); })()), "category", [], "any", false, false, false, 115), "title", [], "any", false, false, false, 115), "html", null, true);
        echo "
\t\t\t\t\t\t</div>

\t\t\t\t\t</div>

\t\t\t\t\t<div class=\"col-3 \">
\t\t\t\t\t\t<div class=\"meta\">Auteur:
\t\t\t\t\t\t\t";
        // line 122
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["figure"]) || array_key_exists("figure", $context) ? $context["figure"] : (function () { throw new RuntimeError('Variable "figure" does not exist.', 122, $this->source); })()), "author", [], "any", false, false, false, 122), "username", [], "any", false, false, false, 122), "html", null, true);
        echo "
\t\t\t\t\t\t</div>

\t\t\t\t\t</div>


\t\t\t\t\t<div class=\"col-sm-3 \">
\t\t\t\t\t\t<div class=\"meta\">Dernière modif :<br>
\t\t\t\t\t\t\t";
        // line 130
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["figure"]) || array_key_exists("figure", $context) ? $context["figure"] : (function () { throw new RuntimeError('Variable "figure" does not exist.', 130, $this->source); })()), "lastModificationAt", [], "any", false, false, false, 130), "d/m/y"), "html", null, true);
        echo "
\t\t\t\t\t\t\tà
\t\t\t\t\t\t\t";
        // line 132
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["figure"]) || array_key_exists("figure", $context) ? $context["figure"] : (function () { throw new RuntimeError('Variable "figure" does not exist.', 132, $this->source); })()), "lastModificationAt", [], "any", false, false, false, 132), "H:i"), "html", null, true);
        echo "
\t\t\t\t\t\t</div>


\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</div>

\t<div class=\"container mt-4\">
\t\t<div class=\"row justify-content-center\">
\t\t\t<div class=\"col-sm-10 col-md-8\">
\t\t\t\t";
        // line 145
        if (twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 145, $this->source); })()), "user", [], "any", false, false, false, 145)) {
            // line 146
            echo "
\t\t\t\t\t<hr>
\t\t\t\t\t";
            // line 148
            echo             $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["commentForm"]) || array_key_exists("commentForm", $context) ? $context["commentForm"] : (function () { throw new RuntimeError('Variable "commentForm" does not exist.', 148, $this->source); })()), 'form_start');
            echo "
\t\t\t\t\t<div class=\"row d-flex align-items-center justify-content-center\">
\t\t\t\t\t\t<div class=\"col-md-10\">
\t\t\t\t\t\t\t";
            // line 151
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["commentForm"]) || array_key_exists("commentForm", $context) ? $context["commentForm"] : (function () { throw new RuntimeError('Variable "commentForm" does not exist.', 151, $this->source); })()), "content", [], "any", false, false, false, 151), 'row', ["label" => " ", "attr" => ["placeholder" => "Veuillez écrire votre message..."]]);
            echo "
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<button type=\"submit\" class=\"btn btn-success\">Envoyer</button>
\t\t\t\t\t</div>

\t\t\t\t\t<hr>
\t\t\t\t\t";
            // line 157
            echo             $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["commentForm"]) || array_key_exists("commentForm", $context) ? $context["commentForm"] : (function () { throw new RuntimeError('Variable "commentForm" does not exist.', 157, $this->source); })()), 'form_end');
            echo "
\t\t\t\t";
        }
        // line 159
        echo "
\t\t\t\t<div id=\"forumComments\">
\t\t\t\t\t";
        // line 161
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["comments"]) || array_key_exists("comments", $context) ? $context["comments"] : (function () { throw new RuntimeError('Variable "comments" does not exist.', 161, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["comment"]) {
            // line 162
            echo "\t\t\t\t\t\t<div class=\"media mb-4 \">
\t\t\t\t\t\t\t<div hidden>
\t\t\t\t\t\t\t\t";
            // line 164
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["comment"], "id", [], "any", false, false, false, 164), "html", null, true);
            echo "
\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t";
            // line 167
            $context["userPicture"] = ((1 === twig_compare(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["comment"], "author", [], "any", false, false, false, 167), "pictures", [], "any", false, false, false, 167), "count", [], "any", false, false, false, 167), 0)) ? (("/uploads/pictures/" . twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["comment"], "author", [], "any", false, false, false, 167), "pictures", [], "any", false, false, false, 167), "first", [], "any", false, false, false, 167), "name", [], "any", false, false, false, 167))) : (null));
            // line 168
            echo "
\t\t\t\t\t\t\t<img src=\" ";
            // line 169
            echo twig_escape_filter($this->env, (((isset($context["userPicture"]) || array_key_exists("userPicture", $context))) ? (_twig_default_filter((isset($context["userPicture"]) || array_key_exists("userPicture", $context) ? $context["userPicture"] : (function () { throw new RuntimeError('Variable "userPicture" does not exist.', 169, $this->source); })()), ("https://eu.ui-avatars.com/api/?name=" . twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["comment"], "author", [], "any", false, false, false, 169), "username", [], "any", false, false, false, 169)))) : (("https://eu.ui-avatars.com/api/?name=" . twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["comment"], "author", [], "any", false, false, false, 169), "username", [], "any", false, false, false, 169)))), "html", null, true);
            echo " \" class=\"d-flex mr-3 rounded-circle user-picture\" alt=\"";
            echo twig_escape_filter($this->env, ("Une image de l'utilisateur" . twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["comment"], "author", [], "any", false, false, false, 169), "username", [], "any", false, false, false, 169)), "html", null, true);
            echo " \">
\t\t\t\t\t\t\t<div class=\"media-body\">
\t\t\t\t\t\t\t\t<h5 class=\"mt-0\">";
            // line 171
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["comment"], "author", [], "any", false, false, false, 171), "username", [], "any", false, false, false, 171), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t(<small>";
            // line 172
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["comment"], "createdAt", [], "any", false, false, false, 172), "d/m/Y à H:i"), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t</small>)</h5>
\t\t\t\t\t\t\t\t<p>";
            // line 174
            echo twig_get_attribute($this->env, $this->source, $context["comment"], "content", [], "any", false, false, false, 174);
            echo "</p>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['comment'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 178
        echo "\t\t\t\t\t";
        // line 179
        echo "\t\t\t\t\t<a class=\"btn-scroll scroll-up\" id=\"js-btn-scroll-up\" href=\"#topJumbotron\" hidden>
\t\t\t\t\t\t<i class=\"fas fa-arrow-up\"></i>
\t\t\t\t\t</a>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>

\t</div>

\t<hr>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 190
    public function block_javascript($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascript"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascript"));

        // line 191
        echo "\t<script src=\" ";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/comments_pagination.js"), "html", null, true);
        echo "\"></script>
\t<script src=\" ";
        // line 192
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/scrollUpBtn.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "app/show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  461 => 192,  456 => 191,  446 => 190,  426 => 179,  424 => 178,  414 => 174,  409 => 172,  405 => 171,  398 => 169,  395 => 168,  393 => 167,  387 => 164,  383 => 162,  379 => 161,  375 => 159,  370 => 157,  361 => 151,  355 => 148,  351 => 146,  349 => 145,  333 => 132,  328 => 130,  317 => 122,  307 => 115,  297 => 108,  286 => 100,  276 => 92,  266 => 88,  262 => 86,  258 => 85,  251 => 80,  239 => 77,  237 => 76,  234 => 75,  230 => 74,  214 => 60,  205 => 54,  199 => 51,  195 => 49,  193 => 48,  186 => 44,  179 => 40,  170 => 35,  168 => 34,  165 => 33,  159 => 32,  156 => 31,  153 => 30,  150 => 29,  145 => 28,  143 => 27,  141 => 26,  138 => 25,  129 => 22,  126 => 21,  121 => 20,  112 => 17,  109 => 16,  105 => 15,  101 => 13,  99 => 12,  96 => 11,  86 => 10,  73 => 7,  63 => 6,  52 => 1,  50 => 3,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}

{% form_theme commentForm 'bootstrap_4_layout.html.twig' %}


{% block title %}
\t{{ figure.title }}
{% endblock %}

{% block body %}

\t{% set defaultPicture = null %}

\t<div class=\"container\">
\t\t{% for message in app.flashes('message') %}
\t\t\t<div class=\"flash-info\">
\t\t\t\t<div class=\"alert alert-success\">{{ message }}</div>
\t\t\t</div>
\t\t{% endfor %}
\t\t{% for message in app.flashes('danger') %}
\t\t\t<div class=\"flash-info\">
\t\t\t\t<div class=\"alert alert-danger\">{{ message }}</div>
\t\t\t</div>
\t\t{% endfor %}

\t\t{% set picturesArray = figure.pictures %}
\t\t{# loop in pictures to find picture with sort_order = 1 #}
\t\t{% for picture in picturesArray %}
\t\t\t{% if picture.sortOrder == 1 %}
\t\t\t\t{% set defaultPicture = picture %}
\t\t\t{% endif %}
\t\t{% endfor %}

\t\t{% set pictureJumbotron = defaultPicture ? \" /uploads/pictures/\" ~ defaultPicture.name : '' %}
\t\t<div class=\"show_main_picture align-items-center justify-content-center\" style=\"background: url(' {{ pictureJumbotron|default('/uploads/pictures/fail.jpg') }} ') no-repeat center;
\t\t\t\t\t\t\t\t\t\tbackground-size: cover;
\t\t\t\t\t\t\t\t\t\tbackground-position: center top;
\t\t\t\t\t\t\t\t\t\theight: 500px;\">
\t\t\t<h1 class=\"display-4\" style=\"color: white\">
\t\t\t\t{{ figure.title|e }}
\t\t\t</h1>

\t\t\t<div hidden id=\"figureId\">
\t\t\t\t{{ figure.id }}
\t\t\t</div>


\t\t\t{% if app.user %}

\t\t\t\t<div class=\"editButtonMenu\">
\t\t\t\t\t<a href=\"{{ path('figure_edit', { id: figure.id }) }}\" class=\"mr-2\">
\t\t\t\t\t\t<i class=\"fas fa-pencil-alt fa-2x\" title=\"modifier la figure\"></i>
\t\t\t\t\t</a>
\t\t\t\t\t<a href=\"{{ path('delete_figure', { id: figure.id }) }}\" onclick=\"return confirm('êtes-vous sûr de vouloir effacer cette figure ?');\">
\t\t\t\t\t\t<i class=\"fas fa-trash-alt fa-2x\" title=\"supprimer la figure\"></i>
\t\t\t\t\t</a>
\t\t\t\t</div>

\t\t\t{% endif %}

\t\t</div>

\t\t<div class=\"container-fluid\">
\t\t\t<div class=\"row justify-content-center d-md-none\">
\t\t\t\t<a data-toggle=\"collapse\" href=\"#media-block-show\" role=\"button\" aria-expanded=\"false\" aria-controls=\"media-block-show\">
\t\t\t\t\t<i class=\"fas fa-images fa-2x\">
\t\t\t\t\t\tVoir les Médias</i>
\t\t\t\t</a>
\t\t\t</div>

\t\t\t<div class=\"row collapse media-block d-md-flex mb-4\" id=\"media-block-show\">
\t\t\t\t<div class=\"col-sm-12 col-md-6 pictures-container\">
\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t{% for picture in picturesArray|filter(picture => picture.sortOrder != 1) %}
\t\t\t\t\t\t\t<div class=\"col-sm-12 col-md-6 col-lg-4 mx-auto\">
\t\t\t\t\t\t\t\t{% set picturePath =  \"/uploads/pictures/\" ~ picture.name %}
\t\t\t\t\t\t\t\t<img class=\"img-responsive\" width=\"100%\" src=\"{{picturePath|default('http://placehold.it/300x200') }}\" alt=\"Une image de la figure {{figure.title}}\" onclick=\"window.open(this.src)\">
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t{% endfor %}
\t\t\t\t\t</div>
\t\t\t\t</div>

\t\t\t\t<div class=\"col-sm-12 col-md-6 videos-container\">
\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t{% for video in figure.videos %}
\t\t\t\t\t\t\t<div class=\" col-sm-12 col-md-6 col-lg-4 mx-auto\">
\t\t\t\t\t\t\t\t<div class=\"iframe-container embed-responsive embed-responsive-16by9\">
\t\t\t\t\t\t\t\t\t<iframe class=\"embed-responsive-item\" src=\"{{video.url}}\" allow=\"accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t{% endfor %}

\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</div>

\t<div class=\"container\">
\t\t<p class=\"lead mt-4 mb-4\">{{ figure.description }}</p>
\t\t<div class=\"row justify-content-center \">
\t\t\t<div class=\"col-lg-8\">

\t\t\t\t<div class=\"row align-items-center meta-box mt-4 mb-4\">

\t\t\t\t\t<div class=\"col-3 \">
\t\t\t\t\t\t<div class=\"meta\">Créée le
\t\t\t\t\t\t\t{{ figure.createdAt|date('d/m/Y') }}
\t\t\t\t\t\t</div>

\t\t\t\t\t</div>

\t\t\t\t\t<div class=\"col-3 \">
\t\t\t\t\t\t<div class=\"meta\">Catégorie
\t\t\t\t\t\t\t{{ figure.category.title }}
\t\t\t\t\t\t</div>

\t\t\t\t\t</div>

\t\t\t\t\t<div class=\"col-3 \">
\t\t\t\t\t\t<div class=\"meta\">Auteur:
\t\t\t\t\t\t\t{{ figure.author.username }}
\t\t\t\t\t\t</div>

\t\t\t\t\t</div>


\t\t\t\t\t<div class=\"col-sm-3 \">
\t\t\t\t\t\t<div class=\"meta\">Dernière modif :<br>
\t\t\t\t\t\t\t{{figure.lastModificationAt|date('d/m/y')}}
\t\t\t\t\t\t\tà
\t\t\t\t\t\t\t{{figure.lastModificationAt|date('H:i')}}
\t\t\t\t\t\t</div>


\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</div>

\t<div class=\"container mt-4\">
\t\t<div class=\"row justify-content-center\">
\t\t\t<div class=\"col-sm-10 col-md-8\">
\t\t\t\t{% if app.user %}

\t\t\t\t\t<hr>
\t\t\t\t\t{{ form_start(commentForm) }}
\t\t\t\t\t<div class=\"row d-flex align-items-center justify-content-center\">
\t\t\t\t\t\t<div class=\"col-md-10\">
\t\t\t\t\t\t\t{{ form_row(commentForm.content, {'label': ' ', 'attr': {'placeholder' : 'Veuillez écrire votre message...' } }) }}
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<button type=\"submit\" class=\"btn btn-success\">Envoyer</button>
\t\t\t\t\t</div>

\t\t\t\t\t<hr>
\t\t\t\t\t{{ form_end(commentForm) }}
\t\t\t\t{% endif %}

\t\t\t\t<div id=\"forumComments\">
\t\t\t\t\t{% for comment in comments %}
\t\t\t\t\t\t<div class=\"media mb-4 \">
\t\t\t\t\t\t\t<div hidden>
\t\t\t\t\t\t\t\t{{ comment.id }}
\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t{% set userPicture = comment.author.pictures.count > 0  ? \"/uploads/pictures/\" ~ comment.author.pictures.first.name : null %}

\t\t\t\t\t\t\t<img src=\" {{ userPicture|default('https://eu.ui-avatars.com/api/?name=' ~ comment.author.username)  }} \" class=\"d-flex mr-3 rounded-circle user-picture\" alt=\"{{ \"Une image de l'utilisateur\" ~ comment.author.username }} \">
\t\t\t\t\t\t\t<div class=\"media-body\">
\t\t\t\t\t\t\t\t<h5 class=\"mt-0\">{{ comment.author.username }}
\t\t\t\t\t\t\t\t\t(<small>{{ comment.createdAt | date('d/m/Y à H:i') }}
\t\t\t\t\t\t\t\t\t</small>)</h5>
\t\t\t\t\t\t\t\t<p>{{ comment.content | raw }}</p>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t{% endfor %}
\t\t\t\t\t{# SCROLL DOWN BUTTON  #}
\t\t\t\t\t<a class=\"btn-scroll scroll-up\" id=\"js-btn-scroll-up\" href=\"#topJumbotron\" hidden>
\t\t\t\t\t\t<i class=\"fas fa-arrow-up\"></i>
\t\t\t\t\t</a>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>

\t</div>

\t<hr>
{% endblock %}
{% block javascript %}
\t<script src=\" {{ asset('js/comments_pagination.js') }}\"></script>
\t<script src=\" {{ asset('js/scrollUpBtn.js') }}\"></script>
{% endblock %}
", "app/show.html.twig", "/home/phil/Snowtricks/templates/app/show.html.twig");
    }
}
