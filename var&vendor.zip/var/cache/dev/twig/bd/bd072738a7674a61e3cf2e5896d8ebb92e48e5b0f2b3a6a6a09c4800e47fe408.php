<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* admin/index.html.twig */
class __TwigTemplate_c28eac5177b4b41372a463c3a8ad88c482c1e93b2b7031f53fca3c641f26ca18 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'body' => [$this, 'block_body'],
            'javascript' => [$this, 'block_javascript'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "admin/index.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "admin/index.html.twig"));

        // line 3
        $context["maxPerPage"] = 5;
        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "admin/index.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 6
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        // line 7
        echo "\tAdministration
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 10
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 11
        echo "\t<div class=\"container\">

\t\t<h1 class=\"title\">Administration</h1>
\t\t<div class=\"mb-5 block-table\">
\t\t\t<div>
\t\t\t\t<h2>Figures</h2>
\t\t\t\t<table class=\"table\" id=\"js-figures\">
\t\t\t\t\t<thead>
\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t<th>ID</th>
\t\t\t\t\t\t\t<th>Titre</th>
\t\t\t\t\t\t\t<th>Categorie</th>
\t\t\t\t\t\t\t<th>Date de dernière modification</th>
\t\t\t\t\t\t\t<th>Auteur</th>
\t\t\t\t\t\t\t<th>Activation</th>
\t\t\t\t\t\t</tr>
\t\t\t\t\t</thead>

\t\t\t\t\t";
        // line 29
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["figures"]) || array_key_exists("figures", $context) ? $context["figures"] : (function () { throw new RuntimeError('Variable "figures" does not exist.', 29, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["figure"]) {
            // line 30
            echo "\t\t\t\t\t\t<tbody>
\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t<td>";
            // line 32
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["figure"], "id", [], "any", false, false, false, 32), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t\t<a href=\"";
            // line 34
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("trick_show", ["id" => twig_get_attribute($this->env, $this->source, $context["figure"], "id", [], "any", false, false, false, 34)]), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["figure"], "title", [], "any", false, false, false, 34), "html", null, true);
            echo "</a>
\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t<td>";
            // line 36
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["figure"], "category", [], "any", false, false, false, 36), "title", [], "any", false, false, false, 36), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t\t<td>";
            // line 37
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["figure"], "createdAt", [], "any", false, false, false, 37)), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t\t<td>";
            // line 38
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["figure"], "author", [], "any", false, false, false, 38), "username", [], "any", false, false, false, 38), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t\t";
            // line 40
            if ( !(null === twig_get_attribute($this->env, $this->source, $context["figure"], "getActivatedAt", [], "any", false, false, false, 40))) {
                // line 41
                echo "\t\t\t\t\t\t\t\t\t\t<a href=\"";
                echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_figure_desactivate", ["id" => twig_get_attribute($this->env, $this->source, $context["figure"], "id", [], "any", false, false, false, 41)]), "html", null, true);
                echo "\" activation=\"true\" class=\"btn btn-warning btn-sm\">Désactiver</a>
\t\t\t\t\t\t\t\t\t";
            } else {
                // line 43
                echo "\t\t\t\t\t\t\t\t\t\t<a href=\"";
                echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_figure_activate", ["id" => twig_get_attribute($this->env, $this->source, $context["figure"], "id", [], "any", false, false, false, 43)]), "html", null, true);
                echo "\" activation=\"false\" class=\"btn btn-success btn-sm\">Activer</a>
\t\t\t\t\t\t\t\t\t";
            }
            // line 45
            echo "\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t</tbody>
\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['figure'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 49
        echo "

\t\t\t\t</table>
\t\t\t</div>

\t\t\t<input type=\"text\" hidden data-figurescount=";
        // line 54
        echo twig_escape_filter($this->env, (isset($context["figuresCount"]) || array_key_exists("figuresCount", $context) ? $context["figuresCount"] : (function () { throw new RuntimeError('Variable "figuresCount" does not exist.', 54, $this->source); })()), "html", null, true);
        echo ">

\t\t\t<a href=\"\" data-figurebtns class=\"link_blog prev\">
\t\t\t\t<i class=\"fas fa-angle-left\"></i>
\t\t\t</a>

\t\t\t";
        // line 60
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(range(1, twig_round(((isset($context["figuresCount"]) || array_key_exists("figuresCount", $context) ? $context["figuresCount"] : (function () { throw new RuntimeError('Variable "figuresCount" does not exist.', 60, $this->source); })()) / (isset($context["maxPerPage"]) || array_key_exists("maxPerPage", $context) ? $context["maxPerPage"] : (function () { throw new RuntimeError('Variable "maxPerPage" does not exist.', 60, $this->source); })())), 0, "ceil")));
        foreach ($context['_seq'] as $context["_key"] => $context["i"]) {
            // line 61
            echo "\t\t\t\t<a href=\"\" data-figurebtns class=\"link_blog\">";
            echo twig_escape_filter($this->env, $context["i"], "html", null, true);
            echo "</a>
\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['i'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 63
        echo "
\t\t\t<a href=\"\" data-figurebtns class=\"link_blog next\">
\t\t\t\t<i class=\"fas fa-angle-right\"></i>
\t\t\t</a>
\t\t</div>


\t\t<div class=\"mb-5 block-table\">
\t\t\t<div>
\t\t\t\t<h2>Commentaires</h2>
\t\t\t\t<table class=\"table\" id=\"js-comments\">
\t\t\t\t\t<thead>
\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t<th>ID</th>
\t\t\t\t\t\t\t<th>Article</th>
\t\t\t\t\t\t\t<th>Contenu</th>
\t\t\t\t\t\t\t<th>Date</th>
\t\t\t\t\t\t\t<th>Auteur</th>
\t\t\t\t\t\t\t<th>Activation</th>
\t\t\t\t\t\t</tr>
\t\t\t\t\t</thead>
\t\t\t\t\t";
        // line 84
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["comments"]) || array_key_exists("comments", $context) ? $context["comments"] : (function () { throw new RuntimeError('Variable "comments" does not exist.', 84, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["comment"]) {
            // line 85
            echo "\t\t\t\t\t\t<tbody>
\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t\t";
            // line 88
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["comment"], "id", [], "any", false, false, false, 88), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t\t<a href=\"";
            // line 90
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("trick_show", ["id" => twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["comment"], "figure", [], "any", false, false, false, 90), "id", [], "any", false, false, false, 90)]), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["comment"], "figure", [], "any", false, false, false, 90), "title", [], "any", false, false, false, 90), "html", null, true);
            echo "</a>
\t\t\t\t\t\t\t\t</td>

\t\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t\t";
            // line 94
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["comment"], "content", [], "any", false, false, false, 94), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t\t";
            // line 96
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["comment"], "createdAt", [], "any", false, false, false, 96)), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t\t";
            // line 98
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["comment"], "author", [], "any", false, false, false, 98), "username", [], "any", false, false, false, 98), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t\t";
            // line 100
            if ( !(null === twig_get_attribute($this->env, $this->source, $context["comment"], "getActivatedAt", [], "any", false, false, false, 100))) {
                // line 101
                echo "\t\t\t\t\t\t\t\t\t\t<a href=\"";
                echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_comment_desactivate", ["id" => twig_get_attribute($this->env, $this->source, $context["comment"], "id", [], "any", false, false, false, 101)]), "html", null, true);
                echo "\" activation=\"true\" class=\"btn btn-warning btn-sm\">Désactiver</a>
\t\t\t\t\t\t\t\t\t";
            } else {
                // line 103
                echo "\t\t\t\t\t\t\t\t\t\t<a href=\"";
                echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_comment_activate", ["id" => twig_get_attribute($this->env, $this->source, $context["comment"], "id", [], "any", false, false, false, 103)]), "html", null, true);
                echo "\" activation=\"false\" class=\"btn btn-success btn-sm\">Activer</a>
\t\t\t\t\t\t\t\t\t";
            }
            // line 105
            echo "\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t</tbody>
\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['comment'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 109
        echo "\t\t\t\t</table>

\t\t\t</div>

\t\t\t<input type=\"text\" hidden data-commentscount=";
        // line 113
        echo twig_escape_filter($this->env, (isset($context["commentsCount"]) || array_key_exists("commentsCount", $context) ? $context["commentsCount"] : (function () { throw new RuntimeError('Variable "commentsCount" does not exist.', 113, $this->source); })()), "html", null, true);
        echo ">

\t\t\t<a href=\"\" data-commentbtns class=\"link_blog prev\">
\t\t\t\t<i class=\"fas fa-angle-left\"></i>
\t\t\t</a>
\t\t\t";
        // line 118
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(range(1, twig_round(((isset($context["commentsCount"]) || array_key_exists("commentsCount", $context) ? $context["commentsCount"] : (function () { throw new RuntimeError('Variable "commentsCount" does not exist.', 118, $this->source); })()) / (isset($context["maxPerPage"]) || array_key_exists("maxPerPage", $context) ? $context["maxPerPage"] : (function () { throw new RuntimeError('Variable "maxPerPage" does not exist.', 118, $this->source); })())), 0, "ceil")));
        foreach ($context['_seq'] as $context["_key"] => $context["j"]) {
            // line 119
            echo "\t\t\t\t<a href=\"\" data-commentbtns class=\"link_blog\">";
            echo twig_escape_filter($this->env, $context["j"], "html", null, true);
            echo "</a>
\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['j'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 121
        echo "\t\t\t<a href=\"\" data-commentbtns class=\"link_blog next\">
\t\t\t\t<i class=\"fas fa-angle-right\"></i>
\t\t\t</a>
\t\t</div>
\t\t<div class=\"mb-5 block-table\">
\t\t\t<div>
\t\t\t\t<h2>Utilisateurs</h2>
\t\t\t\t<table class=\"table\" id=\"js-users\">
\t\t\t\t\t<thead>
\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t<th>ID</th>
\t\t\t\t\t\t\t<th>Pseudonyme</th>
\t\t\t\t\t\t\t<th>Date d'inscription</th>
\t\t\t\t\t\t\t<th>Email</th>
\t\t\t\t\t\t\t<th>Rôle</th>
\t\t\t\t\t\t\t<th>Activation</th>
\t\t\t\t\t\t</tr>
\t\t\t\t\t</thead>
\t\t\t\t\t";
        // line 139
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["users"]) || array_key_exists("users", $context) ? $context["users"] : (function () { throw new RuntimeError('Variable "users" does not exist.', 139, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["user"]) {
            // line 140
            echo "\t\t\t\t\t\t<tbody>
\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t<td>";
            // line 142
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["user"], "id", [], "any", false, false, false, 142), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t\t<td>";
            // line 143
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["user"], "username", [], "any", false, false, false, 143), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t\t<td>";
            // line 144
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["user"], "createdAt", [], "any", false, false, false, 144)), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t\t<td>";
            // line 145
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["user"], "email", [], "any", false, false, false, 145), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t\t<td>";
            // line 146
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["user"], "roles", [], "any", false, false, false, 146), 0, [], "array", false, false, false, 146), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t\t";
            // line 148
            if ((null === twig_get_attribute($this->env, $this->source, $context["user"], "token", [], "any", false, false, false, 148))) {
                // line 149
                echo "\t\t\t\t\t\t\t\t\t\t<a href=\"";
                echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_user_desactivate", ["id" => twig_get_attribute($this->env, $this->source, $context["user"], "id", [], "any", false, false, false, 149)]), "html", null, true);
                echo "\" activation=\"true\" class=\"btn btn-warning btn-sm\">Désactiver</a>
\t\t\t\t\t\t\t\t\t";
            } else {
                // line 151
                echo "\t\t\t\t\t\t\t\t\t\t<a href=\"";
                echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_user_activate", ["id" => twig_get_attribute($this->env, $this->source, $context["user"], "id", [], "any", false, false, false, 151)]), "html", null, true);
                echo "\" activation=\"false\" class=\"btn btn-success btn-sm\">Activer</a>
\t\t\t\t\t\t\t\t\t";
            }
            // line 153
            echo "\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t</tbody>
\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['user'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 157
        echo "\t\t\t\t</table>
\t\t\t</div>

\t\t\t<input type=\"text\" hidden data-userscount=";
        // line 160
        echo twig_escape_filter($this->env, (isset($context["usersCount"]) || array_key_exists("usersCount", $context) ? $context["usersCount"] : (function () { throw new RuntimeError('Variable "usersCount" does not exist.', 160, $this->source); })()), "html", null, true);
        echo ">

\t\t\t<a href=\"\" data-userbtns class=\"link_blog prev\">
\t\t\t\t<i class=\"fas fa-angle-left\"></i>
\t\t\t</a>
\t\t\t";
        // line 165
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(range(1, twig_round(((isset($context["usersCount"]) || array_key_exists("usersCount", $context) ? $context["usersCount"] : (function () { throw new RuntimeError('Variable "usersCount" does not exist.', 165, $this->source); })()) / (isset($context["maxPerPage"]) || array_key_exists("maxPerPage", $context) ? $context["maxPerPage"] : (function () { throw new RuntimeError('Variable "maxPerPage" does not exist.', 165, $this->source); })())), 0, "ceil")));
        foreach ($context['_seq'] as $context["_key"] => $context["k"]) {
            // line 166
            echo "\t\t\t\t<a href=\"\" data-userbtns class=\"link_blog\">";
            echo twig_escape_filter($this->env, $context["k"], "html", null, true);
            echo "</a>
\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['k'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 168
        echo "\t\t\t<a href=\"\" data-userbtns class=\"link_blog next\">
\t\t\t\t<i class=\"fas fa-angle-right\"></i>
\t\t\t</a>
\t\t</div>
\t</div>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 175
    public function block_javascript($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascript"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascript"));

        // line 176
        echo "\t<script src=\" ";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/admin_pagination.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "admin/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  433 => 176,  423 => 175,  408 => 168,  399 => 166,  395 => 165,  387 => 160,  382 => 157,  373 => 153,  367 => 151,  361 => 149,  359 => 148,  354 => 146,  350 => 145,  346 => 144,  342 => 143,  338 => 142,  334 => 140,  330 => 139,  310 => 121,  301 => 119,  297 => 118,  289 => 113,  283 => 109,  274 => 105,  268 => 103,  262 => 101,  260 => 100,  255 => 98,  250 => 96,  245 => 94,  236 => 90,  231 => 88,  226 => 85,  222 => 84,  199 => 63,  190 => 61,  186 => 60,  177 => 54,  170 => 49,  161 => 45,  155 => 43,  149 => 41,  147 => 40,  142 => 38,  138 => 37,  134 => 36,  127 => 34,  122 => 32,  118 => 30,  114 => 29,  94 => 11,  84 => 10,  73 => 7,  63 => 6,  52 => 1,  50 => 3,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}

{% set maxPerPage = 5 %}


{% block title %}
\tAdministration
{% endblock %}

{% block body %}
\t<div class=\"container\">

\t\t<h1 class=\"title\">Administration</h1>
\t\t<div class=\"mb-5 block-table\">
\t\t\t<div>
\t\t\t\t<h2>Figures</h2>
\t\t\t\t<table class=\"table\" id=\"js-figures\">
\t\t\t\t\t<thead>
\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t<th>ID</th>
\t\t\t\t\t\t\t<th>Titre</th>
\t\t\t\t\t\t\t<th>Categorie</th>
\t\t\t\t\t\t\t<th>Date de dernière modification</th>
\t\t\t\t\t\t\t<th>Auteur</th>
\t\t\t\t\t\t\t<th>Activation</th>
\t\t\t\t\t\t</tr>
\t\t\t\t\t</thead>

\t\t\t\t\t{% for figure in figures %}
\t\t\t\t\t\t<tbody>
\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t<td>{{figure.id }}</td>
\t\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t\t<a href=\"{{path('trick_show', {id: figure.id})}}\">{{figure.title }}</a>
\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t<td>{{figure.category.title}}</td>
\t\t\t\t\t\t\t\t<td>{{figure.createdAt|date }}</td>
\t\t\t\t\t\t\t\t<td>{{figure.author.username }}</td>
\t\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t\t{% if figure.getActivatedAt is not null %}
\t\t\t\t\t\t\t\t\t\t<a href=\"{{ path('admin_figure_desactivate', { id: figure.id }) }}\" activation=\"true\" class=\"btn btn-warning btn-sm\">Désactiver</a>
\t\t\t\t\t\t\t\t\t{% else %}
\t\t\t\t\t\t\t\t\t\t<a href=\"{{ path('admin_figure_activate', { id: figure.id }) }}\" activation=\"false\" class=\"btn btn-success btn-sm\">Activer</a>
\t\t\t\t\t\t\t\t\t{% endif %}
\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t</tbody>
\t\t\t\t\t{% endfor %}


\t\t\t\t</table>
\t\t\t</div>

\t\t\t<input type=\"text\" hidden data-figurescount={{ figuresCount }}>

\t\t\t<a href=\"\" data-figurebtns class=\"link_blog prev\">
\t\t\t\t<i class=\"fas fa-angle-left\"></i>
\t\t\t</a>

\t\t\t{% for i in 1..((figuresCount / maxPerPage)|round(0,'ceil')) %}
\t\t\t\t<a href=\"\" data-figurebtns class=\"link_blog\">{{i}}</a>
\t\t\t{% endfor %}

\t\t\t<a href=\"\" data-figurebtns class=\"link_blog next\">
\t\t\t\t<i class=\"fas fa-angle-right\"></i>
\t\t\t</a>
\t\t</div>


\t\t<div class=\"mb-5 block-table\">
\t\t\t<div>
\t\t\t\t<h2>Commentaires</h2>
\t\t\t\t<table class=\"table\" id=\"js-comments\">
\t\t\t\t\t<thead>
\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t<th>ID</th>
\t\t\t\t\t\t\t<th>Article</th>
\t\t\t\t\t\t\t<th>Contenu</th>
\t\t\t\t\t\t\t<th>Date</th>
\t\t\t\t\t\t\t<th>Auteur</th>
\t\t\t\t\t\t\t<th>Activation</th>
\t\t\t\t\t\t</tr>
\t\t\t\t\t</thead>
\t\t\t\t\t{% for comment in comments %}
\t\t\t\t\t\t<tbody>
\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t\t{{comment.id}}</td>
\t\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t\t<a href=\"{{ path( 'trick_show', { id: comment.figure.id })}}\">{{comment.figure.title}}</a>
\t\t\t\t\t\t\t\t</td>

\t\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t\t{{comment.content}}</td>
\t\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t\t{{comment.createdAt | date}}</td>
\t\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t\t{{comment.author.username}}</td>
\t\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t\t{% if comment.getActivatedAt is not null %}
\t\t\t\t\t\t\t\t\t\t<a href=\"{{ path('admin_comment_desactivate', { id: comment.id }) }}\" activation=\"true\" class=\"btn btn-warning btn-sm\">Désactiver</a>
\t\t\t\t\t\t\t\t\t{% else  %}
\t\t\t\t\t\t\t\t\t\t<a href=\"{{ path('admin_comment_activate', { id: comment.id }) }}\" activation=\"false\" class=\"btn btn-success btn-sm\">Activer</a>
\t\t\t\t\t\t\t\t\t{% endif %}
\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t</tbody>
\t\t\t\t\t{% endfor %}
\t\t\t\t</table>

\t\t\t</div>

\t\t\t<input type=\"text\" hidden data-commentscount={{ commentsCount }}>

\t\t\t<a href=\"\" data-commentbtns class=\"link_blog prev\">
\t\t\t\t<i class=\"fas fa-angle-left\"></i>
\t\t\t</a>
\t\t\t{% for j in 1..((commentsCount / maxPerPage)|round(0,'ceil')) %}
\t\t\t\t<a href=\"\" data-commentbtns class=\"link_blog\">{{j}}</a>
\t\t\t{% endfor %}
\t\t\t<a href=\"\" data-commentbtns class=\"link_blog next\">
\t\t\t\t<i class=\"fas fa-angle-right\"></i>
\t\t\t</a>
\t\t</div>
\t\t<div class=\"mb-5 block-table\">
\t\t\t<div>
\t\t\t\t<h2>Utilisateurs</h2>
\t\t\t\t<table class=\"table\" id=\"js-users\">
\t\t\t\t\t<thead>
\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t<th>ID</th>
\t\t\t\t\t\t\t<th>Pseudonyme</th>
\t\t\t\t\t\t\t<th>Date d'inscription</th>
\t\t\t\t\t\t\t<th>Email</th>
\t\t\t\t\t\t\t<th>Rôle</th>
\t\t\t\t\t\t\t<th>Activation</th>
\t\t\t\t\t\t</tr>
\t\t\t\t\t</thead>
\t\t\t\t\t{% for user in users %}
\t\t\t\t\t\t<tbody>
\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t<td>{{user.id}}</td>
\t\t\t\t\t\t\t\t<td>{{user.username}}</td>
\t\t\t\t\t\t\t\t<td>{{user.createdAt | date}}</td>
\t\t\t\t\t\t\t\t<td>{{user.email}}</td>
\t\t\t\t\t\t\t\t<td>{{user.roles[0]}}</td>
\t\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t\t{% if user.token is null %}
\t\t\t\t\t\t\t\t\t\t<a href=\"{{ path('admin_user_desactivate', { id: user.id }) }}\" activation=\"true\" class=\"btn btn-warning btn-sm\">Désactiver</a>
\t\t\t\t\t\t\t\t\t{% else  %}
\t\t\t\t\t\t\t\t\t\t<a href=\"{{ path('admin_user_activate', { id: user.id }) }}\" activation=\"false\" class=\"btn btn-success btn-sm\">Activer</a>
\t\t\t\t\t\t\t\t\t{% endif %}
\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t</tbody>
\t\t\t\t\t{% endfor %}
\t\t\t\t</table>
\t\t\t</div>

\t\t\t<input type=\"text\" hidden data-userscount={{ usersCount }}>

\t\t\t<a href=\"\" data-userbtns class=\"link_blog prev\">
\t\t\t\t<i class=\"fas fa-angle-left\"></i>
\t\t\t</a>
\t\t\t{% for k in 1..((usersCount / maxPerPage)|round(0,'ceil')) %}
\t\t\t\t<a href=\"\" data-userbtns class=\"link_blog\">{{k}}</a>
\t\t\t{% endfor %}
\t\t\t<a href=\"\" data-userbtns class=\"link_blog next\">
\t\t\t\t<i class=\"fas fa-angle-right\"></i>
\t\t\t</a>
\t\t</div>
\t</div>
{% endblock %}

{% block javascript %}
\t<script src=\" {{ asset('js/admin_pagination.js') }}\"></script>
{% endblock %}
", "admin/index.html.twig", "/home/phil/Snowtricks/templates/admin/index.html.twig");
    }
}
