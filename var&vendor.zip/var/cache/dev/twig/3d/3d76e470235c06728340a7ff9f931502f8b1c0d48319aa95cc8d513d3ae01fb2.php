<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* app/sliceFigure.html.twig */
class __TwigTemplate_008145e36bc0799ac9477c0d2f2e61057837cfe38200d6a4b5807a991753932e extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "app/sliceFigure.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "app/sliceFigure.html.twig"));

        // line 1
        echo "<div class=\"col-md-6 col-lg-4\">
\t<div class=\"card mb-4 \">
\t\t<img class=\"card-img-top\" src=\"\" alt=\"\" id=\"js-figPic\">
\t\t<div class=\"card-body\">
\t\t\t<h5 class=\"card-title\" id=\"js-figTitle\">
\t\t\t\t<a href=\"\"></a>
\t\t\t</h5>
\t\t\t<p class=\"card-text\" id=\"js-figText\"></p>
\t\t\t<a href=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("trick_show", ["id" => twig_get_attribute($this->env, $this->source, (isset($context["figure"]) || array_key_exists("figure", $context) ? $context["figure"] : (function () { throw new RuntimeError('Variable "figure" does not exist.', 9, $this->source); })()), "id", [], "any", false, false, false, 9)]), "html", null, true);
        echo "\" class=\"btn btn-primary btn-lg\">Voir</a>
\t\t</div>
\t</div>
</div>
";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "app/sliceFigure.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  53 => 9,  43 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<div class=\"col-md-6 col-lg-4\">
\t<div class=\"card mb-4 \">
\t\t<img class=\"card-img-top\" src=\"\" alt=\"\" id=\"js-figPic\">
\t\t<div class=\"card-body\">
\t\t\t<h5 class=\"card-title\" id=\"js-figTitle\">
\t\t\t\t<a href=\"\"></a>
\t\t\t</h5>
\t\t\t<p class=\"card-text\" id=\"js-figText\"></p>
\t\t\t<a href=\"{{ path('trick_show', { id: figure.id } ) }}\" class=\"btn btn-primary btn-lg\">Voir</a>
\t\t</div>
\t</div>
</div>
", "app/sliceFigure.html.twig", "/home/phil/Snowtricks/templates/app/sliceFigure.html.twig");
    }
}
