<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* app/figure_form.html.twig */
class __TwigTemplate_4b1c222ffd1cb6b18c000cc5665386621e279d67f3c84488589e7abbedd4d371 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'body' => [$this, 'block_body'],
            'javascript' => [$this, 'block_javascript'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "app/figure_form.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "app/figure_form.html.twig"));

        // line 2
        $context["route"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 2, $this->source); })()), "request", [], "any", false, false, false, 2), "attributes", [], "any", false, false, false, 2), "get", [0 => "_route"], "method", false, false, false, 2);
        // line 3
        $context["title"] = ((0 === twig_compare((isset($context["route"]) || array_key_exists("route", $context) ? $context["route"] : (function () { throw new RuntimeError('Variable "route" does not exist.', 3, $this->source); })()), "figure_create")) ? ("Nouvelle figure") : ("Modifier la figure"));
        // line 6
        $this->env->getRuntime("Symfony\\Component\\Form\\FormRenderer")->setTheme((isset($context["figureForm"]) || array_key_exists("figureForm", $context) ? $context["figureForm"] : (function () { throw new RuntimeError('Variable "figureForm" does not exist.', 6, $this->source); })()), [0 => "bootstrap_4_layout.html.twig"], true);
        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "app/figure_form.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 8
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo twig_escape_filter($this->env, (isset($context["title"]) || array_key_exists("title", $context) ? $context["title"] : (function () { throw new RuntimeError('Variable "title" does not exist.', 8, $this->source); })()), "html", null, true);
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 10
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 11
        echo "
\t";
        // line 12
        $context["order"] = 1;
        // line 13
        echo "
\t<div class=\"container\">
\t\t";
        // line 15
        $context["defaultPicture"] = null;
        // line 16
        echo "\t\t";
        if ((isset($context["trick"]) || array_key_exists("trick", $context))) {
            // line 20
            $context["picturesArray"] = twig_get_attribute($this->env, $this->source, (isset($context["trick"]) || array_key_exists("trick", $context) ? $context["trick"] : (function () { throw new RuntimeError('Variable "trick" does not exist.', 20, $this->source); })()), "pictures", [], "any", false, false, false, 20);
            // line 21
            echo "\t\t\t";
            // line 22
            echo "\t\t\t";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["picturesArray"]) || array_key_exists("picturesArray", $context) ? $context["picturesArray"] : (function () { throw new RuntimeError('Variable "picturesArray" does not exist.', 22, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["picture"]) {
                // line 23
                echo "\t\t\t\t";
                if (0 === twig_compare(twig_get_attribute($this->env, $this->source, $context["picture"], "sortOrder", [], "any", false, false, false, 23), 1)) {
                    // line 24
                    echo "\t\t\t\t\t";
                    $context["defaultPicture"] = $context["picture"];
                    // line 25
                    echo "\t\t\t\t";
                }
                // line 26
                echo "\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['picture'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 27
            echo "
\t\t\t";
            // line 28
            $context["pictureJumbotron"] = (((isset($context["defaultPicture"]) || array_key_exists("defaultPicture", $context) ? $context["defaultPicture"] : (function () { throw new RuntimeError('Variable "defaultPicture" does not exist.', 28, $this->source); })())) ? ((" /uploads/pictures/" . twig_get_attribute($this->env, $this->source, (isset($context["defaultPicture"]) || array_key_exists("defaultPicture", $context) ? $context["defaultPicture"] : (function () { throw new RuntimeError('Variable "defaultPicture" does not exist.', 28, $this->source); })()), "name", [], "any", false, false, false, 28))) : (""));
            // line 31
            echo "<div class=\"show_main_picture align-items-center justify-content-center\" style=\"background: url(' ";
            echo twig_escape_filter($this->env, (((isset($context["pictureJumbotron"]) || array_key_exists("pictureJumbotron", $context))) ? (_twig_default_filter((isset($context["pictureJumbotron"]) || array_key_exists("pictureJumbotron", $context) ? $context["pictureJumbotron"] : (function () { throw new RuntimeError('Variable "pictureJumbotron" does not exist.', 31, $this->source); })()), "/uploads/pictures/fail.jpg")) : ("/uploads/pictures/fail.jpg")), "html", null, true);
            echo " ') no-repeat center;
\t\t\t\t\t\t\t\t\tbackground-size: cover;\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\tbackground-position: center top;
\t\t\t\t\t\t\t\t\theight: 500px;\">\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t
\t\t\t\t<h1 class=\"display-4\" style=\"color:white\">";
            // line 35
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["trick"]) || array_key_exists("trick", $context) ? $context["trick"] : (function () { throw new RuntimeError('Variable "trick" does not exist.', 35, $this->source); })()), "title", [], "any", false, false, false, 35), "html", null, true);
            echo "
\t\t\t\t</h1>

\t\t\t\t<div
\t\t\t\t\tclass=\"editButtonMenu\">";
            // line 42
            if ((isset($context["defaultPicture"]) || array_key_exists("defaultPicture", $context) ? $context["defaultPicture"] : (function () { throw new RuntimeError('Variable "defaultPicture" does not exist.', 42, $this->source); })())) {
                // line 43
                echo "\t\t\t\t\t\t<a data-toggle=\"collapse\" href=";
                echo twig_escape_filter($this->env, ("#update_picture_input" . twig_get_attribute($this->env, $this->source, (isset($context["defaultPicture"]) || array_key_exists("defaultPicture", $context) ? $context["defaultPicture"] : (function () { throw new RuntimeError('Variable "defaultPicture" does not exist.', 43, $this->source); })()), "id", [], "any", false, false, false, 43)), "html", null, true);
                echo " role=\"button\" aria-expanded=\"false\" aria-controls=";
                echo twig_escape_filter($this->env, ("update_picture_input" . twig_get_attribute($this->env, $this->source, (isset($context["defaultPicture"]) || array_key_exists("defaultPicture", $context) ? $context["defaultPicture"] : (function () { throw new RuntimeError('Variable "defaultPicture" does not exist.', 43, $this->source); })()), "id", [], "any", false, false, false, 43)), "html", null, true);
                echo ">
\t\t\t\t\t\t\t<i class=\"fas fa-pencil-alt fa-2x\" title=\"remplacer l'image\"></i>
\t\t\t\t\t\t</a>";
                // line 48
                echo "<a href=\"";
                echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("picture_delete", ["id" => twig_get_attribute($this->env, $this->source, (isset($context["defaultPicture"]) || array_key_exists("defaultPicture", $context) ? $context["defaultPicture"] : (function () { throw new RuntimeError('Variable "defaultPicture" does not exist.', 48, $this->source); })()), "id", [], "any", false, false, false, 48)]), "html", null, true);
                echo "\" data-delete>
\t\t\t\t\t\t\t<i class=\"fas fa-trash-alt fa-2x\" title=\"supprimer l'image\"></i>
\t\t\t\t\t\t</a>

\t\t\t\t\t\t";
                // line 53
                echo "<div class=\"collapse\" id=";
                echo twig_escape_filter($this->env, ("update_picture_input" . twig_get_attribute($this->env, $this->source, (isset($context["defaultPicture"]) || array_key_exists("defaultPicture", $context) ? $context["defaultPicture"] : (function () { throw new RuntimeError('Variable "defaultPicture" does not exist.', 53, $this->source); })()), "id", [], "any", false, false, false, 53)), "html", null, true);
                echo ">
\t\t\t\t\t\t\t<input type=\"file\"/>
\t\t\t\t\t\t\t<div hidden>";
                // line 55
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["defaultPicture"]) || array_key_exists("defaultPicture", $context) ? $context["defaultPicture"] : (function () { throw new RuntimeError('Variable "defaultPicture" does not exist.', 55, $this->source); })()), "id", [], "any", false, false, false, 55), "html", null, true);
                echo "</div>
\t\t\t\t\t\t\t<div hidden>";
                // line 56
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["trick"]) || array_key_exists("trick", $context) ? $context["trick"] : (function () { throw new RuntimeError('Variable "trick" does not exist.', 56, $this->source); })()), "id", [], "any", false, false, false, 56), "html", null, true);
                echo "</div>
\t\t\t\t\t\t\t<div hidden>";
                // line 57
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["defaultPicture"]) || array_key_exists("defaultPicture", $context) ? $context["defaultPicture"] : (function () { throw new RuntimeError('Variable "defaultPicture" does not exist.', 57, $this->source); })()), "sortOrder", [], "any", false, false, false, 57), "html", null, true);
                echo "</div>
\t\t\t\t\t\t\t<!-- Picture sortOrder -->
\t\t\t\t\t\t\t<button data-update>Envoyer</button>
\t\t\t\t\t\t</div>

\t\t\t\t\t";
            } else {
                // line 63
                echo "\t\t\t\t\t\t";
                // line 64
                echo "<a data-toggle=\"collapse\" href=\"#new_jumbotron_picture\" role=\"button\" aria-expanded=\"false\" aria-controls=\"new_jumbotron_picture\">
\t\t\t\t\t\t\t<i class=\"fas fa-pencil-alt fa-2x\" title=\"remplacer l'image\"></i>
\t\t\t\t\t\t</a>


\t\t\t\t\t\t<div class=\"collapse\" id=\"new_jumbotron_picture\">
\t\t\t\t\t\t\t<input type=\"file\" id=\"update_picture\"/>
\t\t\t\t\t\t\t<div hidden>";
                // line 71
                echo null;
                echo "</div>
\t\t\t\t\t\t\t<div hidden>";
                // line 72
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["trick"]) || array_key_exists("trick", $context) ? $context["trick"] : (function () { throw new RuntimeError('Variable "trick" does not exist.', 72, $this->source); })()), "id", [], "any", false, false, false, 72), "html", null, true);
                echo "</div>
\t\t\t\t\t\t\t<div hidden>";
                // line 73
                echo 1;
                echo "</div>
\t\t\t\t\t\t\t<!-- Picture sortOrder -->
\t\t\t\t\t\t\t<button data-update>Envoyer</button>
\t\t\t\t\t\t</div>

\t\t\t\t\t";
            }
            // line 79
            echo "
\t\t\t\t";
        } else {
            // line 82
            echo "
\t\t\t\t\t<h1 class=\"title\">Création d'une nouvelle figure de Snowboard</h1>


\t\t\t\t";
        }
        // line 87
        echo "
\t\t\t</div>

\t\t</div>
\t\t<div class=\"row justify-content-center\">

\t\t\t<div id=\"alert\" class=\"alert alert-success\"></div>
\t\t\t";
        // line 94
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 94, $this->source); })()), "flashes", [0 => "danger"], "method", false, false, false, 94));
        foreach ($context['_seq'] as $context["_key"] => $context["message"]) {
            // line 95
            echo "\t\t\t\t<div class=\"flash-info\">
\t\t\t\t\t<div class=\"alert alert-danger\">";
            // line 96
            echo twig_escape_filter($this->env, $context["message"], "html", null, true);
            echo "</div>
\t\t\t\t</div>
\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['message'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 99
        echo "
\t\t</div>";
        // line 103
        echo "<div class=\"container \">
\t\t\t";
        // line 104
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["figureForm"]) || array_key_exists("figureForm", $context) ? $context["figureForm"] : (function () { throw new RuntimeError('Variable "figureForm" does not exist.', 104, $this->source); })()), 'form_start');
        echo "
\t\t\t<div class=\"row justify-content-center d-md-none\">
\t\t\t\t<a data-toggle=\"collapse\" href=\"#media-block\" role=\"button\" aria-expanded=\"false\" aria-controls=\"media-block\">
\t\t\t\t\t<i class=\"fas fa-images fa-2\tx\">Voir les Médias</i>
\t\t\t\t</a>
\t\t\t</div>

\t\t\t<div
\t\t\t\tclass=\"row collapse media-block d-md-flex mb-4\" id=\"media-block\">

\t\t\t\t";
        // line 115
        echo "
\t\t\t\t<div class=\"col-lg-6 pictures-container\">

\t\t\t\t\t<div class=\"row text-center\">
\t\t\t\t\t\t<div class=\"col\">
\t\t\t\t\t\t\t<button type=\"button\" class=\"add-another-picture-widget btn btn-primary\" data-list=\"#pictureList-fields-list\">Ajouter une image</button>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t\t<div class=\"row mt-2 justify_content-center\">
\t\t\t\t\t\t<ul id=\"pictureList-fields-list\" data-prototype='";
        // line 124
        echo twig_escape_filter($this->env, $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["figureForm"]) || array_key_exists("figureForm", $context) ? $context["figureForm"] : (function () { throw new RuntimeError('Variable "figureForm" does not exist.', 124, $this->source); })()), "pictures", [], "any", false, false, false, 124), "vars", [], "any", false, false, false, 124), "prototype", [], "any", false, false, false, 124), 'widget'));
        echo "' data-widget-tags=\"";
        echo twig_escape_filter($this->env, "<li></li>");
        echo "\"></ul>
\t\t\t\t\t</div>


\t\t\t\t\t";
        // line 128
        if ((isset($context["trick"]) || array_key_exists("trick", $context))) {
            // line 129
            echo "\t\t\t\t\t\t<div class=\"row\">

\t\t\t\t\t\t\t";
            // line 131
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(twig_array_filter((isset($context["picturesArray"]) || array_key_exists("picturesArray", $context) ? $context["picturesArray"] : (function () { throw new RuntimeError('Variable "picturesArray" does not exist.', 131, $this->source); })()), function ($__picture__) use ($context, $macros) { $context["picture"] = $__picture__; return 0 !== twig_compare(twig_get_attribute($this->env, $this->source, $context["picture"], "sortOrder", [], "any", false, false, false, 131), 1); }));
            foreach ($context['_seq'] as $context["_key"] => $context["picture"]) {
                // line 132
                echo "\t\t\t\t\t\t\t\t<div hidden>";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["picture"], "id", [], "any", false, false, false, 132), "html", null, true);
                echo "</div>
\t\t\t\t\t\t\t\t<div class=\"col-sm-12 col-md-6 col-lg-4 mx-auto\">
\t\t\t\t\t\t\t\t\t<img
\t\t\t\t\t\t\t\t\tclass=\"img-responsive\" width=\"100%\" src=\"";
                // line 135
                echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl(("/uploads/pictures/" . twig_get_attribute($this->env, $this->source, $context["picture"], "name", [], "any", false, false, false, 135))), "html", null, true);
                echo "\" alt=\"";
                echo twig_escape_filter($this->env, ("Image numéro" . twig_get_attribute($this->env, $this->source, $context["picture"], "id", [], "any", false, false, false, 135)), "html", null, true);
                echo "\" onclick=\"window.open(this.src)\">";
                // line 138
                echo "<a data-toggle=\"collapse\" href=";
                echo twig_escape_filter($this->env, ("#update_picture_input" . twig_get_attribute($this->env, $this->source, $context["picture"], "id", [], "any", false, false, false, 138)), "html", null, true);
                echo " role=\"button\" aria-expanded=\"false\" aria-controls=";
                echo twig_escape_filter($this->env, ("update_picture_input" . twig_get_attribute($this->env, $this->source, $context["picture"], "id", [], "any", false, false, false, 138)), "html", null, true);
                echo ">
\t\t\t\t\t\t\t\t\t\t<i class=\"fas fa-pencil-alt fa-2x\" title=\"remplacer l'image\"></i>
\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t";
                // line 142
                echo "<a href=\"";
                echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("picture_delete", ["id" => twig_get_attribute($this->env, $this->source, $context["picture"], "id", [], "any", false, false, false, 142)]), "html", null, true);
                echo " \" data-delete>
\t\t\t\t\t\t\t\t\t\t<i class=\"fas fa-trash-alt fa-2x\" title=\"effacer l'image\"></i>
\t\t\t\t\t\t\t\t\t</a>

\t\t\t\t\t\t\t\t\t";
                // line 147
                echo "<div class=\"collapse\" id=";
                echo twig_escape_filter($this->env, ("update_picture_input" . twig_get_attribute($this->env, $this->source, $context["picture"], "id", [], "any", false, false, false, 147)), "html", null, true);
                echo ">
\t\t\t\t\t\t\t\t\t\t<input type=\"file\" id=\"update_picture\"/>
\t\t\t\t\t\t\t\t\t\t<div hidden>";
                // line 149
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["picture"], "id", [], "any", false, false, false, 149), "html", null, true);
                echo "</div>
\t\t\t\t\t\t\t\t\t\t<div hidden>";
                // line 150
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["trick"]) || array_key_exists("trick", $context) ? $context["trick"] : (function () { throw new RuntimeError('Variable "trick" does not exist.', 150, $this->source); })()), "id", [], "any", false, false, false, 150), "html", null, true);
                echo "</div>
\t\t\t\t\t\t\t\t\t\t<div hidden>";
                // line 151
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["picture"], "sortOrder", [], "any", false, false, false, 151), "html", null, true);
                echo "</div>
\t\t\t\t\t\t\t\t\t\t<!-- Picture sortOrder -->
\t\t\t\t\t\t\t\t\t\t<button data-update>Envoyer</button>
\t\t\t\t\t\t\t\t\t</div>


\t\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t\t";
                // line 159
                $context["order"] = ((isset($context["order"]) || array_key_exists("order", $context) ? $context["order"] : (function () { throw new RuntimeError('Variable "order" does not exist.', 159, $this->source); })()) + 1);
                // line 160
                echo "\t\t\t\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['picture'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 161
            echo "
\t\t\t\t\t\t</div>
\t\t\t\t\t";
        }
        // line 164
        echo "
\t\t\t\t</div>
\t\t\t\t";
        // line 167
        echo "

\t\t\t\t";
        // line 170
        echo "\t\t\t\t<div class=\"col-lg-6 videos-container\">
\t\t\t\t\t<div class=\"row text-center\">
\t\t\t\t\t\t<div class=\"col\">
\t\t\t\t\t\t\t<button type=\"button\" class=\"add-another-collection-widget btn btn-primary\" data-list=\"#videoList-fields-list\">Ajouter une vidéo</button>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>


\t\t\t\t\t<ul class=\"mt-2\" id=\"videoList-fields-list\" data-prototype='";
        // line 178
        echo twig_escape_filter($this->env, $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["figureForm"]) || array_key_exists("figureForm", $context) ? $context["figureForm"] : (function () { throw new RuntimeError('Variable "figureForm" does not exist.', 178, $this->source); })()), "videos", [], "any", false, false, false, 178), "vars", [], "any", false, false, false, 178), "prototype", [], "any", false, false, false, 178), 'widget'));
        echo "' data-widget-tags=\"";
        echo twig_escape_filter($this->env, "<li></li>");
        echo "\"></ul>

\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t";
        // line 181
        if ((isset($context["trick"]) || array_key_exists("trick", $context))) {
            // line 182
            echo "\t\t\t\t\t\t\t";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, (isset($context["trick"]) || array_key_exists("trick", $context) ? $context["trick"] : (function () { throw new RuntimeError('Variable "trick" does not exist.', 182, $this->source); })()), "videos", [], "any", false, false, false, 182));
            foreach ($context['_seq'] as $context["_key"] => $context["video"]) {
                // line 183
                echo "\t\t\t\t\t\t\t\t<div class=\" col-sm-12 col-md-6 col-lg-4 mx-auto\">
\t\t\t\t\t\t\t\t\t<div class=\"embed-responsive embed-responsive-16by9\">
\t\t\t\t\t\t\t\t\t\t<iframe class=\"embed-responsive-item\" src=\"";
                // line 185
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["video"], "url", [], "any", false, false, false, 185), "html", null, true);
                echo "\" frameborder=\"0\" allow=\"accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<a data-toggle=\"collapse\" href=";
                // line 187
                echo twig_escape_filter($this->env, ("#update_video_input" . twig_get_attribute($this->env, $this->source, $context["video"], "id", [], "any", false, false, false, 187)), "html", null, true);
                echo " role=\"button\" aria-expanded=\"false\" aria-controls=";
                echo twig_escape_filter($this->env, ("update_video_input" . twig_get_attribute($this->env, $this->source, $context["video"], "id", [], "any", false, false, false, 187)), "html", null, true);
                echo ">
\t\t\t\t\t\t\t\t\t\t<i class=\"fas fa-pencil-alt fa-2x\" title=\"remplacer la vidéo\"></i>
\t\t\t\t\t\t\t\t\t</a>

\t\t\t\t\t\t\t\t\t<a href=\"";
                // line 191
                echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("video_delete", ["id" => twig_get_attribute($this->env, $this->source, $context["video"], "id", [], "any", false, false, false, 191)]), "html", null, true);
                echo " \" data-delete>
\t\t\t\t\t\t\t\t\t\t<i class=\"fas fa-trash-alt fa-2x\" title=\"supprimer la vidéo\"></i>
\t\t\t\t\t\t\t\t\t</a>


\t\t\t\t\t\t\t\t\t<div class=\"collapse\" id=";
                // line 196
                echo twig_escape_filter($this->env, ("update_video_input" . twig_get_attribute($this->env, $this->source, $context["video"], "id", [], "any", false, false, false, 196)), "html", null, true);
                echo ">
\t\t\t\t\t\t\t\t\t\t<input type=\"text\" id=\"newVideoUrl\"/>
\t\t\t\t\t\t\t\t\t\t<div hidden>";
                // line 198
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["video"], "id", [], "any", false, false, false, 198), "html", null, true);
                echo "</div>
\t\t\t\t\t\t\t\t\t\t<div hidden>";
                // line 199
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["trick"]) || array_key_exists("trick", $context) ? $context["trick"] : (function () { throw new RuntimeError('Variable "trick" does not exist.', 199, $this->source); })()), "id", [], "any", false, false, false, 199), "html", null, true);
                echo "</div>
\t\t\t\t\t\t\t\t\t\t<button data-update>Envoyer</button>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['video'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 204
            echo "\t\t\t\t\t\t";
        }
        // line 205
        echo "\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t";
        // line 208
        echo "
\t\t\t</div>


\t\t\t";
        // line 212
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["figureForm"]) || array_key_exists("figureForm", $context) ? $context["figureForm"] : (function () { throw new RuntimeError('Variable "figureForm" does not exist.', 212, $this->source); })()), "title", [], "any", false, false, false, 212), 'row');
        echo "
\t\t\t";
        // line 213
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["figureForm"]) || array_key_exists("figureForm", $context) ? $context["figureForm"] : (function () { throw new RuntimeError('Variable "figureForm" does not exist.', 213, $this->source); })()), "description", [], "any", false, false, false, 213), 'row');
        echo "


\t\t\t<div class=\"row\">
\t\t\t\t<div class=\"col-sm-3\">
\t\t\t\t\t";
        // line 218
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["figureForm"]) || array_key_exists("figureForm", $context) ? $context["figureForm"] : (function () { throw new RuntimeError('Variable "figureForm" does not exist.', 218, $this->source); })()), "category", [], "any", false, false, false, 218), 'row');
        echo "
\t\t\t\t</div>
\t\t\t\t<div class=\"col d-flex justify-content-end align-items-center form-group\">
\t\t\t\t\t";
        // line 221
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["figureForm"]) || array_key_exists("figureForm", $context) ? $context["figureForm"] : (function () { throw new RuntimeError('Variable "figureForm" does not exist.', 221, $this->source); })()), "submit", [], "any", false, false, false, 221), 'widget');
        echo "
\t\t\t\t</div>
\t\t\t</div>
\t\t\t";
        // line 224
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["figureForm"]) || array_key_exists("figureForm", $context) ? $context["figureForm"] : (function () { throw new RuntimeError('Variable "figureForm" does not exist.', 224, $this->source); })()), 'form_end');
        echo "

\t\t</div>
\t";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 229
    public function block_javascript($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascript"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascript"));

        // line 230
        echo "\t\t<script src=\" ";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/media_delete.js"), "html", null, true);
        echo " \"></script>
\t\t<script src=\" ";
        // line 231
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/media_update.js"), "html", null, true);
        echo " \"></script>
\t\t<script src=\" ";
        // line 232
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/add_video.js"), "html", null, true);
        echo " \"></script>
\t\t<script src=\" ";
        // line 233
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/add_picture.js"), "html", null, true);
        echo " \"></script>
\t";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "app/figure_form.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  528 => 233,  524 => 232,  520 => 231,  515 => 230,  505 => 229,  491 => 224,  485 => 221,  479 => 218,  471 => 213,  467 => 212,  461 => 208,  457 => 205,  454 => 204,  443 => 199,  439 => 198,  434 => 196,  426 => 191,  417 => 187,  412 => 185,  408 => 183,  403 => 182,  401 => 181,  393 => 178,  383 => 170,  379 => 167,  375 => 164,  370 => 161,  364 => 160,  362 => 159,  351 => 151,  347 => 150,  343 => 149,  337 => 147,  329 => 142,  320 => 138,  315 => 135,  308 => 132,  304 => 131,  300 => 129,  298 => 128,  289 => 124,  278 => 115,  265 => 104,  262 => 103,  259 => 99,  250 => 96,  247 => 95,  243 => 94,  234 => 87,  227 => 82,  223 => 79,  214 => 73,  210 => 72,  206 => 71,  197 => 64,  195 => 63,  186 => 57,  182 => 56,  178 => 55,  172 => 53,  164 => 48,  156 => 43,  154 => 42,  147 => 35,  139 => 31,  137 => 28,  134 => 27,  128 => 26,  125 => 25,  122 => 24,  119 => 23,  114 => 22,  112 => 21,  110 => 20,  107 => 16,  105 => 15,  101 => 13,  99 => 12,  96 => 11,  86 => 10,  67 => 8,  56 => 1,  54 => 6,  52 => 3,  50 => 2,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends \"base.html.twig\" %}
{% set route = app.request.attributes.get('_route') %}
{% set title = route == \"figure_create\" ? \"Nouvelle figure\" : \"Modifier la figure\" %}


{% form_theme figureForm 'bootstrap_4_layout.html.twig' %}

{% block title title %}

{% block body %}

\t{% set order = 1 %}

\t<div class=\"container\">
\t\t{% set defaultPicture = null %}
\t\t{% if trick is defined %}

\t\t\t{#----------------------------------EDIT FIGURE--------------------------------------------#}

\t\t\t{% set picturesArray = trick.pictures %}
\t\t\t{# loop in pictures to find picture with sort_order = 1 #}
\t\t\t{% for picture in picturesArray %}
\t\t\t\t{% if picture.sortOrder == 1 %}
\t\t\t\t\t{% set defaultPicture = picture %}
\t\t\t\t{% endif %}
\t\t\t{% endfor %}

\t\t\t{% set pictureJumbotron = defaultPicture ? \" /uploads/pictures/\" ~ defaultPicture.name : '' %}

\t\t\t{#------------------------JUMBOTRON---------------------------#}
\t\t\t<div class=\"show_main_picture align-items-center justify-content-center\" style=\"background: url(' {{ pictureJumbotron|default('/uploads/pictures/fail.jpg') }} ') no-repeat center;
\t\t\t\t\t\t\t\t\tbackground-size: cover;\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\tbackground-position: center top;
\t\t\t\t\t\t\t\t\theight: 500px;\">\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t
\t\t\t\t<h1 class=\"display-4\" style=\"color:white\">{{trick.title}}
\t\t\t\t</h1>

\t\t\t\t<div
\t\t\t\t\tclass=\"editButtonMenu\">

\t\t\t\t\t{#-----------UPDATE PICTURE --------#}
\t\t\t\t\t{% if defaultPicture %}
\t\t\t\t\t\t<a data-toggle=\"collapse\" href={{\"#update_picture_input\" ~ defaultPicture.id }} role=\"button\" aria-expanded=\"false\" aria-controls={{\"update_picture_input\" ~ defaultPicture.id }}>
\t\t\t\t\t\t\t<i class=\"fas fa-pencil-alt fa-2x\" title=\"remplacer l'image\"></i>
\t\t\t\t\t\t</a>

\t\t\t\t\t\t{#---------DELETE PICTURE---------#}
\t\t\t\t\t\t<a href=\"{{ path('picture_delete', { id: defaultPicture.id }) }}\" data-delete>
\t\t\t\t\t\t\t<i class=\"fas fa-trash-alt fa-2x\" title=\"supprimer l'image\"></i>
\t\t\t\t\t\t</a>

\t\t\t\t\t\t{#!---------UPDATE PICTURE HIDDEN INPUT---------#}
\t\t\t\t\t\t<div class=\"collapse\" id={{\"update_picture_input\" ~ defaultPicture.id }}>
\t\t\t\t\t\t\t<input type=\"file\"/>
\t\t\t\t\t\t\t<div hidden>{{ defaultPicture.id }}</div>
\t\t\t\t\t\t\t<div hidden>{{ trick.id }}</div>
\t\t\t\t\t\t\t<div hidden>{{ defaultPicture.sortOrder }}</div>
\t\t\t\t\t\t\t<!-- Picture sortOrder -->
\t\t\t\t\t\t\t<button data-update>Envoyer</button>
\t\t\t\t\t\t</div>

\t\t\t\t\t{% else %}
\t\t\t\t\t\t{#!---------NEW-JUMBOTRON PICTURE--------#}
\t\t\t\t\t\t<a data-toggle=\"collapse\" href=\"#new_jumbotron_picture\" role=\"button\" aria-expanded=\"false\" aria-controls=\"new_jumbotron_picture\">
\t\t\t\t\t\t\t<i class=\"fas fa-pencil-alt fa-2x\" title=\"remplacer l'image\"></i>
\t\t\t\t\t\t</a>


\t\t\t\t\t\t<div class=\"collapse\" id=\"new_jumbotron_picture\">
\t\t\t\t\t\t\t<input type=\"file\" id=\"update_picture\"/>
\t\t\t\t\t\t\t<div hidden>{{ null}}</div>
\t\t\t\t\t\t\t<div hidden>{{ trick.id }}</div>
\t\t\t\t\t\t\t<div hidden>{{1}}</div>
\t\t\t\t\t\t\t<!-- Picture sortOrder -->
\t\t\t\t\t\t\t<button data-update>Envoyer</button>
\t\t\t\t\t\t</div>

\t\t\t\t\t{% endif %}

\t\t\t\t{% else %}
\t\t\t\t\t{#---------------------------------NEW FIGURE------------------------------------------     #}

\t\t\t\t\t<h1 class=\"title\">Création d'une nouvelle figure de Snowboard</h1>


\t\t\t\t{% endif %}

\t\t\t</div>

\t\t</div>
\t\t<div class=\"row justify-content-center\">

\t\t\t<div id=\"alert\" class=\"alert alert-success\"></div>
\t\t\t{% for message in app.flashes('danger') %}
\t\t\t\t<div class=\"flash-info\">
\t\t\t\t\t<div class=\"alert alert-danger\">{{ message }}</div>
\t\t\t\t</div>
\t\t\t{% endfor %}

\t\t</div>
\t\t{#-----FLASH MESSAGES------#}

\t\t<div class=\"container \">
\t\t\t{{ form_start(figureForm) }}
\t\t\t<div class=\"row justify-content-center d-md-none\">
\t\t\t\t<a data-toggle=\"collapse\" href=\"#media-block\" role=\"button\" aria-expanded=\"false\" aria-controls=\"media-block\">
\t\t\t\t\t<i class=\"fas fa-images fa-2\tx\">Voir les Médias</i>
\t\t\t\t</a>
\t\t\t</div>

\t\t\t<div
\t\t\t\tclass=\"row collapse media-block d-md-flex mb-4\" id=\"media-block\">

\t\t\t\t{# -------------------------FIGURES PICTURES------------------------ #}

\t\t\t\t<div class=\"col-lg-6 pictures-container\">

\t\t\t\t\t<div class=\"row text-center\">
\t\t\t\t\t\t<div class=\"col\">
\t\t\t\t\t\t\t<button type=\"button\" class=\"add-another-picture-widget btn btn-primary\" data-list=\"#pictureList-fields-list\">Ajouter une image</button>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t\t<div class=\"row mt-2 justify_content-center\">
\t\t\t\t\t\t<ul id=\"pictureList-fields-list\" data-prototype='{{form_widget(figureForm.pictures.vars.prototype)|e}}' data-widget-tags=\"{{ '<li></li>'|e }}\"></ul>
\t\t\t\t\t</div>


\t\t\t\t\t{% if trick is defined %}
\t\t\t\t\t\t<div class=\"row\">

\t\t\t\t\t\t\t{% for picture in picturesArray|filter(picture => picture.sortOrder != 1) %}
\t\t\t\t\t\t\t\t<div hidden>{{ picture.id }}</div>
\t\t\t\t\t\t\t\t<div class=\"col-sm-12 col-md-6 col-lg-4 mx-auto\">
\t\t\t\t\t\t\t\t\t<img
\t\t\t\t\t\t\t\t\tclass=\"img-responsive\" width=\"100%\" src=\"{{ asset('/uploads/pictures/' ~ picture.name) }}\" alt=\"{{\"Image numéro\" ~ picture.id}}\" onclick=\"window.open(this.src)\">

\t\t\t\t\t\t\t\t\t{#-----------UPDATE PICTURE --------#}
\t\t\t\t\t\t\t\t\t<a data-toggle=\"collapse\" href={{\"#update_picture_input\" ~ picture.id }} role=\"button\" aria-expanded=\"false\" aria-controls={{\"update_picture_input\" ~ picture.id }}>
\t\t\t\t\t\t\t\t\t\t<i class=\"fas fa-pencil-alt fa-2x\" title=\"remplacer l'image\"></i>
\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t{#!---------DELETE PICTURE---------#}
\t\t\t\t\t\t\t\t\t<a href=\"{{ path('picture_delete', {id: picture.id}) }} \" data-delete>
\t\t\t\t\t\t\t\t\t\t<i class=\"fas fa-trash-alt fa-2x\" title=\"effacer l'image\"></i>
\t\t\t\t\t\t\t\t\t</a>

\t\t\t\t\t\t\t\t\t{#!---------UPDATE PICTURE HIDDEN INPUT---------#}
\t\t\t\t\t\t\t\t\t<div class=\"collapse\" id={{\"update_picture_input\" ~ picture.id }}>
\t\t\t\t\t\t\t\t\t\t<input type=\"file\" id=\"update_picture\"/>
\t\t\t\t\t\t\t\t\t\t<div hidden>{{ picture.id }}</div>
\t\t\t\t\t\t\t\t\t\t<div hidden>{{ trick.id }}</div>
\t\t\t\t\t\t\t\t\t\t<div hidden>{{ picture.sortOrder }}</div>
\t\t\t\t\t\t\t\t\t\t<!-- Picture sortOrder -->
\t\t\t\t\t\t\t\t\t\t<button data-update>Envoyer</button>
\t\t\t\t\t\t\t\t\t</div>


\t\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t\t{% set order = order +1 %}
\t\t\t\t\t\t\t{% endfor %}

\t\t\t\t\t\t</div>
\t\t\t\t\t{% endif %}

\t\t\t\t</div>
\t\t\t\t{# -------------------------FIGURES PICTURES------------------------ #}


\t\t\t\t{# -------------------------FIGURES VIDEOS------------------------ #}
\t\t\t\t<div class=\"col-lg-6 videos-container\">
\t\t\t\t\t<div class=\"row text-center\">
\t\t\t\t\t\t<div class=\"col\">
\t\t\t\t\t\t\t<button type=\"button\" class=\"add-another-collection-widget btn btn-primary\" data-list=\"#videoList-fields-list\">Ajouter une vidéo</button>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>


\t\t\t\t\t<ul class=\"mt-2\" id=\"videoList-fields-list\" data-prototype='{{form_widget(figureForm.videos.vars.prototype)|e}}' data-widget-tags=\"{{ '<li></li>'|e }}\"></ul>

\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t{% if trick is defined %}
\t\t\t\t\t\t\t{% for video in trick.videos %}
\t\t\t\t\t\t\t\t<div class=\" col-sm-12 col-md-6 col-lg-4 mx-auto\">
\t\t\t\t\t\t\t\t\t<div class=\"embed-responsive embed-responsive-16by9\">
\t\t\t\t\t\t\t\t\t\t<iframe class=\"embed-responsive-item\" src=\"{{video.url}}\" frameborder=\"0\" allow=\"accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<a data-toggle=\"collapse\" href={{\"#update_video_input\" ~ video.id }} role=\"button\" aria-expanded=\"false\" aria-controls={{\"update_video_input\" ~ video.id }}>
\t\t\t\t\t\t\t\t\t\t<i class=\"fas fa-pencil-alt fa-2x\" title=\"remplacer la vidéo\"></i>
\t\t\t\t\t\t\t\t\t</a>

\t\t\t\t\t\t\t\t\t<a href=\"{{ path('video_delete', {id: video.id}) }} \" data-delete>
\t\t\t\t\t\t\t\t\t\t<i class=\"fas fa-trash-alt fa-2x\" title=\"supprimer la vidéo\"></i>
\t\t\t\t\t\t\t\t\t</a>


\t\t\t\t\t\t\t\t\t<div class=\"collapse\" id={{\"update_video_input\" ~ video.id }}>
\t\t\t\t\t\t\t\t\t\t<input type=\"text\" id=\"newVideoUrl\"/>
\t\t\t\t\t\t\t\t\t\t<div hidden>{{ video.id }}</div>
\t\t\t\t\t\t\t\t\t\t<div hidden>{{ trick.id }}</div>
\t\t\t\t\t\t\t\t\t\t<button data-update>Envoyer</button>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t{% endfor %}
\t\t\t\t\t\t{% endif %}
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t{# -------------------------FIGURES VIDEOS------------------------ #}

\t\t\t</div>


\t\t\t{{ form_row(figureForm.title) }}
\t\t\t{{ form_row(figureForm.description) }}


\t\t\t<div class=\"row\">
\t\t\t\t<div class=\"col-sm-3\">
\t\t\t\t\t{{ form_row(figureForm.category) }}
\t\t\t\t</div>
\t\t\t\t<div class=\"col d-flex justify-content-end align-items-center form-group\">
\t\t\t\t\t{{ form_widget(figureForm.submit) }}
\t\t\t\t</div>
\t\t\t</div>
\t\t\t{{ form_end(figureForm) }}

\t\t</div>
\t{% endblock %}

\t{% block javascript %}
\t\t<script src=\" {{ asset('js/media_delete.js') }} \"></script>
\t\t<script src=\" {{ asset('js/media_update.js') }} \"></script>
\t\t<script src=\" {{ asset('js/add_video.js') }} \"></script>
\t\t<script src=\" {{ asset('js/add_picture.js') }} \"></script>
\t{% endblock %}
", "app/figure_form.html.twig", "/home/phil/Snowtricks/templates/app/figure_form.html.twig");
    }
}
