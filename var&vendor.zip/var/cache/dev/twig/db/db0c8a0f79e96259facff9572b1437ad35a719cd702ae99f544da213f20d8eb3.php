<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* base.html.twig */
class __TwigTemplate_764817ae7a8caea551e2cdab66ec51c321ce96efe62761f3302ffe0e6a23fa79 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'body' => [$this, 'block_body'],
            'javascript' => [$this, 'block_javascript'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        $context["route_name"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 1, $this->source); })()), "request", [], "any", false, false, false, 1), "attributes", [], "any", false, false, false, 1), "get", [0 => "_route"], "method", false, false, false, 1);
        // line 2
        echo "<!DOCTYPE html>
<html>
\t<head>
\t\t<meta charset=\"UTF-8\"/>
\t\t<meta name=\"viewport\" content=\"width=device-width, initial-scale=1, shrink-to-fit=no\">
\t\t<meta name=\"description\" content=\"SnwotricksBlog\">
\t\t<meta name=\"author\" content=\"JamingPhilippe\">
\t\t<link rel=\"stylesheet\" href=\"https://bootswatch.com/4/cosmo/bootstrap.min.css\"/>
\t\t<script src=\"https://kit.fontawesome.com/0f7e81f372.js\" crossorigin=\"anonymous\"></script>
\t\t<link rel=\"stylesheet\" type=\"text/css\" href=\" ";
        // line 11
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("/css/main.css"), "html", null, true);
        echo "\">
\t\t<title>
\t\t\t";
        // line 13
        $this->displayBlock('title', $context, $blocks);
        // line 14
        echo "\t\t</title>
\t</head>

\t<body>

\t\t<nav class=\"navbar navbar-expand-lg fixed-top bg-primary navbar-dark justify-content-end navbar-desk\">
\t\t\t<a class=\"navbar-brand font-weight-bold\" href=\"";
        // line 20
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("home");
        echo "\">
\t\t\t\t<img src=\" ";
        // line 21
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("uploads/pictures/logo.png"), "html", null, true);
        echo " \" width=\"50\" height=\"50\" alt=\"Info Logo\">
\t\t\t\tSnowtricks
\t\t\t</a>
\t\t\t<button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\" data-target=\"#navbarContent\" aria-controls=\"navbarContent\" aria-expanded=\"false\" aria-label=\"Toggle navigation\">
\t\t\t\t<span class=\"navbar-toggler-icon\"></span>
\t\t\t</button>
\t\t\t<div class=\"collapse navbar-collapse \" id=\"navbarContent\">
\t\t\t\t<ul class=\"navbar-nav ml-auto\">
\t\t\t\t\t<li ";
        // line 29
        if (0 === twig_compare((isset($context["route_name"]) || array_key_exists("route_name", $context) ? $context["route_name"] : (function () { throw new RuntimeError('Variable "route_name" does not exist.', 29, $this->source); })()), "home")) {
            echo " class=\"nav-item active\" ";
        } else {
            echo " class=\"nav-item\" ";
        }
        echo ">
\t\t\t\t\t\t<a class=\"nav-link\" href=\"";
        // line 30
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("home");
        echo "\">
\t\t\t\t\t\t\tAccueil
\t\t\t\t\t\t</a>
\t\t\t\t\t</li>
\t\t\t\t\t";
        // line 34
        if ( !twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 34, $this->source); })()), "user", [], "any", false, false, false, 34)) {
            // line 35
            echo "\t\t\t\t\t\t<li ";
            if (0 === twig_compare((isset($context["route_name"]) || array_key_exists("route_name", $context) ? $context["route_name"] : (function () { throw new RuntimeError('Variable "route_name" does not exist.', 35, $this->source); })()), "security_login")) {
                echo " class=\"nav-item active\" ";
            } else {
                echo " class=\"nav-item\" ";
            }
            echo ">
\t\t\t\t\t\t\t<a href=\"";
            // line 36
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("security_login");
            echo "\" class=\"nav-link\">Connexion</a>
\t\t\t\t\t\t</li>
\t\t\t\t\t\t<li ";
            // line 38
            if (0 === twig_compare((isset($context["route_name"]) || array_key_exists("route_name", $context) ? $context["route_name"] : (function () { throw new RuntimeError('Variable "route_name" does not exist.', 38, $this->source); })()), "security_registration")) {
                echo " class=\"nav-item active\" ";
            } else {
                echo " class=\"nav-item\" ";
            }
            echo ">
\t\t\t\t\t\t\t<a href=\"";
            // line 39
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("security_registration");
            echo " \" class=\"nav-link\">Enregistrement</a>
\t\t\t\t\t\t</li>
\t\t\t\t\t";
        } else {
            // line 42
            echo "\t\t\t\t\t\t";
            if (0 === twig_compare(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 42, $this->source); })()), "user", [], "any", false, false, false, 42), "roles", [], "any", false, false, false, 42), 0, [], "array", false, false, false, 42), "ROLE_ADMIN")) {
                // line 43
                echo "\t\t\t\t\t\t\t<li class=\"nav-item\">
\t\t\t\t\t\t\t\t<a href=\"";
                // line 44
                echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin");
                echo "\" class=\"nav-link\">Admin</a>
\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t";
            }
            // line 47
            echo "\t\t\t\t\t\t<li class=\"nav-item\">
\t\t\t\t\t\t\t<a href=\" ";
            // line 48
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("profile");
            echo " \" class=\"nav-link\">Profil</a>
\t\t\t\t\t\t</li>
\t\t\t\t\t\t<li class=\"nav-item\">
\t\t\t\t\t\t\t<a href=\"";
            // line 51
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("security_logout");
            echo "\" class=\"nav-link\">Déconnexion</a>
\t\t\t\t\t\t</li>
\t\t\t\t\t\t<li ";
            // line 53
            if (0 === twig_compare((isset($context["route_name"]) || array_key_exists("route_name", $context) ? $context["route_name"] : (function () { throw new RuntimeError('Variable "route_name" does not exist.', 53, $this->source); })()), "figure_create")) {
                echo " class=\"nav-item active\" ";
            } else {
                echo " class=\"nav-item\" ";
            }
            echo ">
\t\t\t\t\t\t\t<a href=\"";
            // line 54
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("figure_create");
            echo " \" class=\"nav-link\">Poster</a>
\t\t\t\t\t\t</li>
\t\t\t\t\t";
        }
        // line 57
        echo "\t\t\t\t</ul>
\t\t\t</div>
\t\t</nav>

\t\t<!--BODY-->
\t\t<div class=\"toto\"> ";
        // line 62
        $this->displayBlock('body', $context, $blocks);
        // line 63
        echo "\t\t\t</div>

\t\t\t<!--FOOTER-->

\t\t\t<div class=\"container-fluid footer-mob\">
\t\t\t\t<div class=\"row d-flex justify-content-center \">
\t\t\t\t\t<div class=\"col-6\">
\t\t\t\t\t\t<div class=\"d-flex justify-content-center row navbar\">
\t\t\t\t\t\t\t<div class=\"col text-center\">
\t\t\t\t\t\t\t\t<a href=\"";
        // line 72
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("home");
        echo "\">
\t\t\t\t\t\t\t\t\t<i class=\"fas fa-home fa-3x\"></i>
\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"col text-center\">
\t\t\t\t\t\t\t\t<button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\" data-target=\"#footer-navbar-collapse\" aria-controls=\"footer-navbar-collapse\" aria-expanded=\"false\" aria-label=\"Toggle navigation\" style=\"color: #2780e3;\">

\t\t\t\t\t\t\t\t\t<i class=\"fas fa-bars fa-2x\"></i>

\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t\t<div class=\"collapse navbar-collapse\" id=\"footer-navbar-collapse\">
\t\t\t\t\t\t\t\t\t<ul>
\t\t\t\t\t\t\t\t\t\t<li ";
        // line 84
        if (0 === twig_compare((isset($context["route_name"]) || array_key_exists("route_name", $context) ? $context["route_name"] : (function () { throw new RuntimeError('Variable "route_name" does not exist.', 84, $this->source); })()), "home")) {
            echo " class=\"nav-item active\" ";
        } else {
            echo " class=\"nav-item\" ";
        }
        echo ">
\t\t\t\t\t\t\t\t\t\t\t<a class=\"nav-link\" href=\"";
        // line 85
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("home");
        echo "\">
\t\t\t\t\t\t\t\t\t\t\t\tAccueil
\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t\t";
        // line 89
        if (twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 89, $this->source); })()), "user", [], "any", false, false, false, 89)) {
            // line 90
            echo "\t\t\t\t\t\t\t\t\t\t\t";
            if (0 === twig_compare(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 90, $this->source); })()), "user", [], "any", false, false, false, 90), "roles", [], "any", false, false, false, 90), 0, [], "array", false, false, false, 90), "ROLE_ADMIN")) {
                // line 91
                echo "\t\t\t\t\t\t\t\t\t\t\t\t<li class=\"nav-item\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"";
                // line 92
                echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin");
                echo "\" class=\"nav-link\">Admin</a>
\t\t\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t\t\t";
            }
            // line 95
            echo "\t\t\t\t\t\t\t\t\t\t";
        }
        // line 96
        echo "\t\t\t\t\t\t\t\t\t\t<li class=\"nav-item\">
\t\t\t\t\t\t\t\t\t\t\t<a href=\" ";
        // line 97
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("profile");
        echo " \" class=\"nav-link\">Profil</a>
\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t\t<li ";
        // line 99
        if (0 === twig_compare((isset($context["route_name"]) || array_key_exists("route_name", $context) ? $context["route_name"] : (function () { throw new RuntimeError('Variable "route_name" does not exist.', 99, $this->source); })()), "figure_create")) {
            echo " class=\"nav-item active\" ";
        } else {
            echo " class=\"nav-item\" ";
        }
        echo ">
\t\t\t\t\t\t\t\t\t\t\t<a href=\"";
        // line 100
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("figure_create");
        echo " \" class=\"nav-link\">Poster</a>
\t\t\t\t\t\t\t\t\t\t</li>

\t\t\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t";
        // line 106
        if (twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 106, $this->source); })()), "user", [], "any", false, false, false, 106)) {
            // line 107
            echo "\t\t\t\t\t\t\t\t<div class=\"col text-center\">
\t\t\t\t\t\t\t\t\t<a href=\"";
            // line 108
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("security_logout");
            echo "\">
\t\t\t\t\t\t\t\t\t\t<i class=\"fas fa-sign-out-alt fa-3x\"></i>
\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t";
        } else {
            // line 113
            echo "\t\t\t\t\t\t\t\t<div class=\"col text-center\">
\t\t\t\t\t\t\t\t\t<a href=\"";
            // line 114
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("security_login");
            echo "\">
\t\t\t\t\t\t\t\t\t\t<i class=\"fas fa-sign-in-alt fa-3x\"></i>
\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t";
        }
        // line 119
        echo "\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>

\t\t\t<div class=\"bg-light\">
\t\t\t\t<div class=\"container footer-desk\">
\t\t\t\t\t<div class=\"row mt-4\">
\t\t\t\t\t\t<div class=\"col\">
\t\t\t\t\t\t\t<ul class=\"list-inline text-center\">
\t\t\t\t\t\t\t\t<li class=\"list-inline-item\">
\t\t\t\t\t\t\t\t\t<a href=\"#\">À propos</a>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t<li class=\"list-inline-item\">&middot;</li>
\t\t\t\t\t\t\t\t<li class=\"list-inline-item\">
\t\t\t\t\t\t\t\t\t<a href=\"#\">Vie privée</a>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t<li class=\"list-inline-item\">&middot;</li>
\t\t\t\t\t\t\t\t<li class=\"list-inline-item\">
\t\t\t\t\t\t\t\t\t<a href=\"#\">Conditions d'utilisations</a>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>


\t\t\t</div>
\t\t\t<!--/FOOTER-->
\t\t\t<script src=\"https://code.jquery.com/jquery-3.4.1.slim.min.js\" integrity=\"sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n\" crossorigin=\"anonymous\"></script>
\t\t\t<script src=\"https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js\" integrity=\"sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo\" crossorigin=\"anonymous\"></script>
\t\t\t<script src=\"https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js\" integrity=\"sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6\" crossorigin=\"anonymous\"></script>

\t\t\t";
        // line 152
        $this->displayBlock('javascript', $context, $blocks);
        // line 153
        echo "
\t\t</body>

\t</html>
";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 13
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 62
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 152
    public function block_javascript($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascript"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascript"));

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  377 => 152,  359 => 62,  341 => 13,  327 => 153,  325 => 152,  290 => 119,  282 => 114,  279 => 113,  271 => 108,  268 => 107,  266 => 106,  257 => 100,  249 => 99,  244 => 97,  241 => 96,  238 => 95,  232 => 92,  229 => 91,  226 => 90,  224 => 89,  217 => 85,  209 => 84,  194 => 72,  183 => 63,  181 => 62,  174 => 57,  168 => 54,  160 => 53,  155 => 51,  149 => 48,  146 => 47,  140 => 44,  137 => 43,  134 => 42,  128 => 39,  120 => 38,  115 => 36,  106 => 35,  104 => 34,  97 => 30,  89 => 29,  78 => 21,  74 => 20,  66 => 14,  64 => 13,  59 => 11,  48 => 2,  46 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% set route_name = app.request.attributes.get('_route') %}
<!DOCTYPE html>
<html>
\t<head>
\t\t<meta charset=\"UTF-8\"/>
\t\t<meta name=\"viewport\" content=\"width=device-width, initial-scale=1, shrink-to-fit=no\">
\t\t<meta name=\"description\" content=\"SnwotricksBlog\">
\t\t<meta name=\"author\" content=\"JamingPhilippe\">
\t\t<link rel=\"stylesheet\" href=\"https://bootswatch.com/4/cosmo/bootstrap.min.css\"/>
\t\t<script src=\"https://kit.fontawesome.com/0f7e81f372.js\" crossorigin=\"anonymous\"></script>
\t\t<link rel=\"stylesheet\" type=\"text/css\" href=\" {{ asset('/css/main.css') }}\">
\t\t<title>
\t\t\t{% block title %}{% endblock %}
\t\t</title>
\t</head>

\t<body>

\t\t<nav class=\"navbar navbar-expand-lg fixed-top bg-primary navbar-dark justify-content-end navbar-desk\">
\t\t\t<a class=\"navbar-brand font-weight-bold\" href=\"{{ path('home') }}\">
\t\t\t\t<img src=\" {{ asset('uploads/pictures/logo.png') }} \" width=\"50\" height=\"50\" alt=\"Info Logo\">
\t\t\t\tSnowtricks
\t\t\t</a>
\t\t\t<button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\" data-target=\"#navbarContent\" aria-controls=\"navbarContent\" aria-expanded=\"false\" aria-label=\"Toggle navigation\">
\t\t\t\t<span class=\"navbar-toggler-icon\"></span>
\t\t\t</button>
\t\t\t<div class=\"collapse navbar-collapse \" id=\"navbarContent\">
\t\t\t\t<ul class=\"navbar-nav ml-auto\">
\t\t\t\t\t<li {% if route_name == \"home\" %} class=\"nav-item active\" {% else %} class=\"nav-item\" {% endif %}>
\t\t\t\t\t\t<a class=\"nav-link\" href=\"{{ path('home') }}\">
\t\t\t\t\t\t\tAccueil
\t\t\t\t\t\t</a>
\t\t\t\t\t</li>
\t\t\t\t\t{% if not app.user %}
\t\t\t\t\t\t<li {% if route_name == \"security_login\" %} class=\"nav-item active\" {% else %} class=\"nav-item\" {% endif %}>
\t\t\t\t\t\t\t<a href=\"{{path('security_login')}}\" class=\"nav-link\">Connexion</a>
\t\t\t\t\t\t</li>
\t\t\t\t\t\t<li {% if route_name == \"security_registration\" %} class=\"nav-item active\" {% else %} class=\"nav-item\" {% endif %}>
\t\t\t\t\t\t\t<a href=\"{{ path('security_registration')}} \" class=\"nav-link\">Enregistrement</a>
\t\t\t\t\t\t</li>
\t\t\t\t\t{% else %}
\t\t\t\t\t\t{% if (app.user.roles[0] == \"ROLE_ADMIN\") %}
\t\t\t\t\t\t\t<li class=\"nav-item\">
\t\t\t\t\t\t\t\t<a href=\"{{ path('admin')}}\" class=\"nav-link\">Admin</a>
\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t{% endif %}
\t\t\t\t\t\t<li class=\"nav-item\">
\t\t\t\t\t\t\t<a href=\" {{ path('profile') }} \" class=\"nav-link\">Profil</a>
\t\t\t\t\t\t</li>
\t\t\t\t\t\t<li class=\"nav-item\">
\t\t\t\t\t\t\t<a href=\"{{ path('security_logout') }}\" class=\"nav-link\">Déconnexion</a>
\t\t\t\t\t\t</li>
\t\t\t\t\t\t<li {% if route_name == \"figure_create\" %} class=\"nav-item active\" {% else %} class=\"nav-item\" {% endif %}>
\t\t\t\t\t\t\t<a href=\"{{ path('figure_create') }} \" class=\"nav-link\">Poster</a>
\t\t\t\t\t\t</li>
\t\t\t\t\t{% endif %}
\t\t\t\t</ul>
\t\t\t</div>
\t\t</nav>

\t\t<!--BODY-->
\t\t<div class=\"toto\"> {% block body %}{% endblock %}
\t\t\t</div>

\t\t\t<!--FOOTER-->

\t\t\t<div class=\"container-fluid footer-mob\">
\t\t\t\t<div class=\"row d-flex justify-content-center \">
\t\t\t\t\t<div class=\"col-6\">
\t\t\t\t\t\t<div class=\"d-flex justify-content-center row navbar\">
\t\t\t\t\t\t\t<div class=\"col text-center\">
\t\t\t\t\t\t\t\t<a href=\"{{ path('home') }}\">
\t\t\t\t\t\t\t\t\t<i class=\"fas fa-home fa-3x\"></i>
\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"col text-center\">
\t\t\t\t\t\t\t\t<button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\" data-target=\"#footer-navbar-collapse\" aria-controls=\"footer-navbar-collapse\" aria-expanded=\"false\" aria-label=\"Toggle navigation\" style=\"color: #2780e3;\">

\t\t\t\t\t\t\t\t\t<i class=\"fas fa-bars fa-2x\"></i>

\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t\t<div class=\"collapse navbar-collapse\" id=\"footer-navbar-collapse\">
\t\t\t\t\t\t\t\t\t<ul>
\t\t\t\t\t\t\t\t\t\t<li {% if route_name == \"home\" %} class=\"nav-item active\" {% else %} class=\"nav-item\" {% endif %}>
\t\t\t\t\t\t\t\t\t\t\t<a class=\"nav-link\" href=\"{{ path('home') }}\">
\t\t\t\t\t\t\t\t\t\t\t\tAccueil
\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t\t{% if app.user %}
\t\t\t\t\t\t\t\t\t\t\t{% if (app.user.roles[0] == \"ROLE_ADMIN\") %}
\t\t\t\t\t\t\t\t\t\t\t\t<li class=\"nav-item\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"{{ path('admin')}}\" class=\"nav-link\">Admin</a>
\t\t\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t\t\t{% endif %}
\t\t\t\t\t\t\t\t\t\t{% endif %}
\t\t\t\t\t\t\t\t\t\t<li class=\"nav-item\">
\t\t\t\t\t\t\t\t\t\t\t<a href=\" {{ path('profile') }} \" class=\"nav-link\">Profil</a>
\t\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t\t<li {% if route_name == \"figure_create\" %} class=\"nav-item active\" {% else %} class=\"nav-item\" {% endif %}>
\t\t\t\t\t\t\t\t\t\t\t<a href=\"{{ path('figure_create') }} \" class=\"nav-link\">Poster</a>
\t\t\t\t\t\t\t\t\t\t</li>

\t\t\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t{% if app.user %}
\t\t\t\t\t\t\t\t<div class=\"col text-center\">
\t\t\t\t\t\t\t\t\t<a href=\"{{ path('security_logout') }}\">
\t\t\t\t\t\t\t\t\t\t<i class=\"fas fa-sign-out-alt fa-3x\"></i>
\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t{% else %}
\t\t\t\t\t\t\t\t<div class=\"col text-center\">
\t\t\t\t\t\t\t\t\t<a href=\"{{ path('security_login') }}\">
\t\t\t\t\t\t\t\t\t\t<i class=\"fas fa-sign-in-alt fa-3x\"></i>
\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t{% endif %}
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>

\t\t\t<div class=\"bg-light\">
\t\t\t\t<div class=\"container footer-desk\">
\t\t\t\t\t<div class=\"row mt-4\">
\t\t\t\t\t\t<div class=\"col\">
\t\t\t\t\t\t\t<ul class=\"list-inline text-center\">
\t\t\t\t\t\t\t\t<li class=\"list-inline-item\">
\t\t\t\t\t\t\t\t\t<a href=\"#\">À propos</a>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t<li class=\"list-inline-item\">&middot;</li>
\t\t\t\t\t\t\t\t<li class=\"list-inline-item\">
\t\t\t\t\t\t\t\t\t<a href=\"#\">Vie privée</a>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t<li class=\"list-inline-item\">&middot;</li>
\t\t\t\t\t\t\t\t<li class=\"list-inline-item\">
\t\t\t\t\t\t\t\t\t<a href=\"#\">Conditions d'utilisations</a>
\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>


\t\t\t</div>
\t\t\t<!--/FOOTER-->
\t\t\t<script src=\"https://code.jquery.com/jquery-3.4.1.slim.min.js\" integrity=\"sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n\" crossorigin=\"anonymous\"></script>
\t\t\t<script src=\"https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js\" integrity=\"sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo\" crossorigin=\"anonymous\"></script>
\t\t\t<script src=\"https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js\" integrity=\"sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6\" crossorigin=\"anonymous\"></script>

\t\t\t{% block javascript %}{% endblock %}

\t\t</body>

\t</html>
", "base.html.twig", "/home/phil/Snowtricks/templates/base.html.twig");
    }
}
